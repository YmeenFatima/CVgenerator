<?php
$pageTitle = 'Admin Users';
require_once 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if ($name && $email && $username && $password) {
        $hash = hashPassword($password);
        try {
            $db->prepare("INSERT INTO admin_users (username, email, password, full_name, role) VALUES (?,?,?,?,?)")
                ->execute([$username, $email, $hash, $name, $role]);
            setFlash('success', 'Admin user created successfully!');
        } catch (Exception $e) {
            setFlash('danger', 'Email or username already exists.');
        }
    }
    header('Location: admins.php'); exit;
}

if (isset($_GET['toggle'])) {
    $uid = (int)$_GET['toggle'];
    if ($uid !== $_SESSION['admin_id']) {
        $db->query("UPDATE admin_users SET is_active = NOT is_active WHERE id=$uid");
    }
    header('Location: admins.php'); exit;
}

$admins = $db->query("SELECT * FROM admin_users ORDER BY created_at DESC")->fetchAll();
$showForm = isset($_GET['action']) && $_GET['action'] === 'new';
?>
<div class="topbar">
    <div class="page-title"><i class="fas fa-user-shield" style="color:var(--accent)"></i> Admin Users</div>
    <div class="topbar-actions">
        <a href="?action=new" class="topbar-btn primary"><i class="fas fa-plus"></i> Add Admin</a>
    </div>
</div>
<div class="content">
<?php if ($showForm): ?>
    <div class="card" style="max-width:600px;margin-bottom:1.5rem">
        <div class="card-header">
            <div class="card-title">Create New Admin User</div>
            <a href="admins.php" class="btn btn-secondary btn-sm">Cancel</a>
        </div>
        <form method="POST">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
                <div class="form-group">
                    <label class="form-label">Full Name *</label>
                    <input type="text" name="full_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Username *</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Password *</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <select name="role" class="form-control">
                        <option value="reviewer">Reviewer</option>
                        <option value="admin">Admin</option>
                        <option value="super_admin">Super Admin</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create Admin</button>
        </form>
    </div>
<?php endif; ?>
    <div class="card">
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>Name</th><th>Email</th><th>Role</th><th>Last Login</th><th>Status</th><th>Action</th></tr>
                </thead>
                <tbody>
                <?php foreach ($admins as $a): ?>
                    <tr>
                        <td>
                            <div style="font-weight:600"><?= htmlspecialchars($a['full_name']) ?></div>
                            <div style="font-size:0.77rem;color:var(--text-muted)">@<?= htmlspecialchars($a['username']) ?></div>
                        </td>
                        <td style="font-size:0.85rem"><?= htmlspecialchars($a['email']) ?></td>
                        <td><span class="badge badge-info"><?= ucfirst(str_replace('_',' ',$a['role'])) ?></span></td>
                        <td style="font-size:0.8rem;color:var(--text-muted)"><?= $a['last_login'] ? formatDate($a['last_login'], 'd M Y H:i') : 'Never' ?></td>
                        <td><?= $a['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>' ?></td>
                        <td>
                            <?php if ($a['id'] !== $_SESSION['admin_id']): ?>
                                <a href="?toggle=<?= $a['id'] ?>" class="btn btn-warning btn-sm"><i class="fas fa-toggle-on"></i></a>
                            <?php else: ?>
                                <span style="font-size:0.78rem;color:var(--text-muted)">(You)</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>