<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireAdmin();
header('Location: ' . ADMIN_URL . '/dashboard.php');
exit;
