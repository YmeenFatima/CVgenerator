<?php
$pageTitle = 'Template Manager';
require_once 'includes/header.php';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add' || $action === 'edit') {
        $title = sanitize($_POST['title'] ?? '');
        $description = sanitize($_POST['description'] ?? '');
        $category_id = intval($_POST['category_id'] ?? 0);
        $tags = sanitize($_POST['tags'] ?? '');
        $is_featured = isset($_POST['is_featured']) ? 1 : 0;
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        // File upload
        $file_path = $_POST['existing_file'] ?? '';
        $file_type = $_POST['existing_type'] ?? 'pdf';
        $file_size = 0;
        if (!empty($_FILES['template_file']['name'])) {
            $ext = strtolower(pathinfo($_FILES['template_file']['name'], PATHINFO_EXTENSION));
            $allowed = ['zip','pdf','docx','doc','psd','ai'];
            if (in_array($ext, $allowed) && $_FILES['template_file']['size'] <= 10*1024*1024) {
                $fname = 'tpl_' . time() . '_' . uniqid() . '.' . $ext;
                $dest = __DIR__ . '/../uploads/templates/' . $fname;
                if (move_uploaded_file($_FILES['template_file']['tmp_name'], $dest)) {
                    $file_path = 'templates/' . $fname;
                    $file_type = $ext;
                    $file_size = $_FILES['template_file']['size'];
                }
            }
        }
        
        // Preview image upload
        $preview_image = $_POST['existing_preview'] ?? '';
        if (!empty($_FILES['preview_image']['name'])) {
            $ext = strtolower(pathinfo($_FILES['preview_image']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg','jpeg','png','webp']) && $_FILES['preview_image']['size'] <= 5*1024*1024) {
                $fname = 'prev_' . time() . '_' . uniqid() . '.' . $ext;
                $dest = __DIR__ . '/../uploads/previews/' . $fname;
                if (move_uploaded_file($_FILES['preview_image']['tmp_name'], $dest)) {
                    $preview_image = 'previews/' . $fname;
                }
            }
        }
        
        if ($action === 'add') {
            $db->prepare("INSERT INTO downloadable_templates (title,description,category_id,file_path,preview_image,file_type,file_size,is_featured,is_active,tags,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
               ->execute([$title,$description,$category_id,$file_path,$preview_image,$file_type,$file_size,$is_featured,$is_active,$tags,$_SESSION['admin_id']]);
            setFlash('success', 'Template added successfully!');
        } else {
            $eid = intval($_POST['edit_id'] ?? 0);
            $db->prepare("UPDATE downloadable_templates SET title=?,description=?,category_id=?,file_path=?,preview_image=?,file_type=?,is_featured=?,is_active=?,tags=? WHERE id=?")
               ->execute([$title,$description,$category_id,$file_path,$preview_image,$file_type,$is_featured,$is_active,$tags,$eid]);
            setFlash('success', 'Template updated!');
        }
        header('Location: templates_manage.php'); exit;
    }
    
    if ($action === 'delete') {
        $did = intval($_POST['delete_id'] ?? 0);
        $db->prepare("DELETE FROM downloadable_templates WHERE id=?")->execute([$did]);
        setFlash('success', 'Template deleted.');
        header('Location: templates_manage.php'); exit;
    }
}

// Get data
$cats = $db->query("SELECT * FROM template_categories ORDER BY sort_order")->fetchAll();
$templates = $db->query("SELECT t.*, c.name as cat_name FROM downloadable_templates t JOIN template_categories c ON t.category_id=c.id ORDER BY t.created_at DESC")->fetchAll();
$totalDownloads = $db->query("SELECT COALESCE(SUM(download_count),0) FROM downloadable_templates")->fetchColumn();
?>

<div class="topbar">
    <span class="topbar-title"><i class="fas fa-layer-group" style="color:#6366f1"></i> Template Manager</span>
    <button class="btn btn-sm" style="background:#6366f1;color:#fff;font-weight:600;border-radius:8px" data-bs-toggle="modal" data-bs-target="#addModal"><i class="fas fa-plus me-1"></i>Add Template</button>
</div>
<div class="content-area">
    <!-- Stats -->
    <div class="row g-3 mb-4">
        <div class="col-md-3"><div class="stat-card"><div class="d-flex justify-content-between align-items-center"><div><div class="stat-num" style="color:#6366f1"><?= count($templates) ?></div><div class="stat-label">Total Templates</div></div><div class="stat-icon" style="background:rgba(99,102,241,0.12)"><i class="fas fa-layer-group" style="color:#6366f1"></i></div></div></div></div>
        <div class="col-md-3"><div class="stat-card"><div class="d-flex justify-content-between align-items-center"><div><div class="stat-num" style="color:#10b981"><?= $totalDownloads ?></div><div class="stat-label">Total Downloads</div></div><div class="stat-icon" style="background:rgba(16,185,129,0.12)"><i class="fas fa-download" style="color:#10b981"></i></div></div></div></div>
        <div class="col-md-3"><div class="stat-card"><div class="d-flex justify-content-between align-items-center"><div><div class="stat-num" style="color:#f59e0b"><?= count($cats) ?></div><div class="stat-label">Categories</div></div><div class="stat-icon" style="background:rgba(245,158,11,0.12)"><i class="fas fa-tags" style="color:#f59e0b"></i></div></div></div></div>
        <div class="col-md-3"><div class="stat-card"><div class="d-flex justify-content-between align-items-center"><div><div class="stat-num" style="color:#ef4444"><?= count(array_filter($templates, fn($t)=>$t['is_featured'])) ?></div><div class="stat-label">Featured</div></div><div class="stat-icon" style="background:rgba(239,68,68,0.12)"><i class="fas fa-star" style="color:#ef4444"></i></div></div></div></div>
    </div>

    <!-- Table -->
    <div class="card" style="background:#1e293b;border:1px solid rgba(255,255,255,0.07);border-radius:14px;overflow:hidden">
        <div class="table-responsive">
        <table class="table table-dark-custom mb-0">
            <thead><tr><th>#</th><th>Template</th><th>Category</th><th>Type</th><th>Downloads</th><th>Featured</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach($templates as $i=>$t): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><strong><?= htmlspecialchars($t['title']) ?></strong><br><small style="color:#64748b"><?= htmlspecialchars(substr($t['description']??'',0,60)) ?>...</small></td>
                <td><?= htmlspecialchars($t['cat_name']) ?></td>
                <td><span class="badge bg-secondary"><?= strtoupper($t['file_type']) ?></span></td>
                <td><i class="fas fa-download me-1" style="color:#6366f1"></i><?= $t['download_count'] ?></td>
                <td><?= $t['is_featured'] ? '<i class="fas fa-star" style="color:#f59e0b"></i>' : '<i class="far fa-star" style="color:#475569"></i>' ?></td>
                <td><?= $t['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>' ?></td>
                <td>
                    <button class="btn btn-sm" style="background:rgba(99,102,241,0.12);color:#6366f1;font-size:0.75rem;border-radius:6px" onclick="editTpl(<?= htmlspecialchars(json_encode($t)) ?>)"><i class="fas fa-edit"></i></button>
                    <form method="POST" style="display:inline" onsubmit="return confirm('Delete this template?')">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="delete_id" value="<?= $t['id'] ?>">
                        <button class="btn btn-sm" style="background:rgba(239,68,68,0.12);color:#ef4444;font-size:0.75rem;border-radius:6px"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
<div class="modal-dialog modal-lg"><div class="modal-content" style="background:#1e293b;border:1px solid rgba(255,255,255,0.1)">
<div class="modal-header" style="border-color:rgba(255,255,255,0.08)"><h5 class="modal-title" id="modalTitle" style="font-family:'Sora',sans-serif;font-weight:700;color:#f1f5f9">Add Template</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<form method="POST" enctype="multipart/form-data" id="tplForm">
<input type="hidden" name="action" id="formAction" value="add">
<input type="hidden" name="edit_id" id="editId" value="">
<input type="hidden" name="existing_file" id="existingFile" value="">
<input type="hidden" name="existing_preview" id="existingPreview" value="">
<input type="hidden" name="existing_type" id="existingType" value="pdf">
<div class="modal-body">
    <div class="row g-3">
        <div class="col-md-8"><label class="form-label" style="color:#94a3b8;font-size:0.82rem">Title</label><input type="text" name="title" id="fTitle" class="form-control" required></div>
        <div class="col-md-4"><label class="form-label" style="color:#94a3b8;font-size:0.82rem">Category</label><select name="category_id" id="fCat" class="form-select" required><?php foreach($cats as $c): ?><option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option><?php endforeach; ?></select></div>
        <div class="col-12"><label class="form-label" style="color:#94a3b8;font-size:0.82rem">Description</label><textarea name="description" id="fDesc" class="form-control" rows="3"></textarea></div>
        <div class="col-md-6"><label class="form-label" style="color:#94a3b8;font-size:0.82rem">Template File (ZIP/PDF/DOCX, max 10MB)</label><input type="file" name="template_file" class="form-control" accept=".zip,.pdf,.docx,.doc,.psd,.ai"></div>
        <div class="col-md-6"><label class="form-label" style="color:#94a3b8;font-size:0.82rem">Preview Image (JPG/PNG)</label><input type="file" name="preview_image" class="form-control" accept="image/*"></div>
        <div class="col-md-6"><label class="form-label" style="color:#94a3b8;font-size:0.82rem">Tags (comma separated)</label><input type="text" name="tags" id="fTags" class="form-control" placeholder="modern, clean, ats"></div>
        <div class="col-md-3"><div class="form-check mt-4"><input type="checkbox" name="is_featured" id="fFeatured" class="form-check-input" value="1"><label class="form-check-label" style="color:#94a3b8;font-size:0.85rem" for="fFeatured">Featured</label></div></div>
        <div class="col-md-3"><div class="form-check mt-4"><input type="checkbox" name="is_active" id="fActive" class="form-check-input" value="1" checked><label class="form-check-label" style="color:#94a3b8;font-size:0.85rem" for="fActive">Active</label></div></div>
    </div>
</div>
<div class="modal-footer" style="border-color:rgba(255,255,255,0.08)"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn" style="background:#6366f1;color:#fff;font-weight:600">Save Template</button></div>
</form>
</div></div>
</div>

<script>
function editTpl(t) {
    document.getElementById('formAction').value = 'edit';
    document.getElementById('editId').value = t.id;
    document.getElementById('fTitle').value = t.title;
    document.getElementById('fDesc').value = t.description || '';
    document.getElementById('fCat').value = t.category_id;
    document.getElementById('fTags').value = t.tags || '';
    document.getElementById('fFeatured').checked = t.is_featured == 1;
    document.getElementById('fActive').checked = t.is_active == 1;
    document.getElementById('existingFile').value = t.file_path || '';
    document.getElementById('existingPreview').value = t.preview_image || '';
    document.getElementById('existingType').value = t.file_type || 'pdf';
    document.getElementById('modalTitle').textContent = 'Edit Template';
    new bootstrap.Modal(document.getElementById('addModal')).show();
}
</script>
<?php require_once 'includes/footer.php'; ?>
