<?php
$pageTitle = 'Dashboard';
require_once 'includes/header.php';

// Dashboard Stats - CV Builder focused
try {
    $totalCandidates = $db->query("SELECT COUNT(*) FROM candidates")->fetchColumn();
    $totalCvs        = $db->query("SELECT COUNT(*) FROM cvs")->fetchColumn();
    $downloads       = $db->query("SELECT COUNT(*) FROM download_history")->fetchColumn();
    $totalTemplates  = $db->query("SELECT COUNT(*) FROM cv_templates")->fetchColumn();
    $totalLetters    = $db->query("SELECT COUNT(*) FROM cover_letters")->fetchColumn();
    $recentCandidates = $db->query("SELECT * FROM candidates ORDER BY created_at DESC LIMIT 8")->fetchAll();
    $recentCvs = $db->query("SELECT cv.*, CONCAT(c.first_name,' ',c.last_name) as cand_name FROM cvs cv JOIN candidates c ON cv.candidate_id=c.id ORDER BY cv.created_at DESC LIMIT 8")->fetchAll();
} catch(Exception $e) {
    $totalCandidates = $totalCvs = $downloads = $totalTemplates = $totalLetters = 0;
    $recentCandidates = $recentCvs = [];
}
?>
<div class="content">
  <!-- Page Header -->
  <div style="margin-bottom:1.5rem;display:flex;align-items:center;justify-content:space-between">
    <div>
      <h1 style="font-family:'Sora',sans-serif;font-size:1.5rem;font-weight:800;color:#1e293b;margin:0">Dashboard</h1>
      <p style="color:#64748b;font-size:0.85rem;margin:0.2rem 0 0">Welcome back, <?= htmlspecialchars($currentAdmin['full_name']??'Admin') ?>! Here's your overview.</p>
    </div>
    <div style="display:flex;gap:0.7rem">
      <a href="templates_manage.php" class="btn-sm btn-primary" style="padding:0.55rem 1.1rem;text-decoration:none;border-radius:10px;font-size:0.83rem"><i class="fas fa-layer-group"></i> Manage Templates</a>
      <a href="candidates.php" class="btn-sm btn-secondary" style="padding:0.55rem 1.1rem;text-decoration:none;border-radius:10px;font-size:0.83rem"><i class="fas fa-users"></i> View Candidates</a>
    </div>
  </div>

  <!-- Stats Boxes -->
  <div class="stats-grid">
    <div class="stat-card">
      <div class="icon" style="background:rgba(99,102,241,0.1)"><i class="fas fa-users" style="color:#6366f1"></i></div>
      <div>
        <div class="num"><?= number_format($totalCandidates) ?></div>
        <div class="label">Total Candidates</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="icon" style="background:rgba(16,185,129,0.1)"><i class="fas fa-file-lines" style="color:#10b981"></i></div>
      <div>
        <div class="num"><?= number_format($totalCvs) ?></div>
        <div class="label">CVs Created</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="icon" style="background:rgba(245,158,11,0.1)"><i class="fas fa-download" style="color:#f59e0b"></i></div>
      <div>
        <div class="num"><?= number_format($downloads) ?></div>
        <div class="label">Downloads</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="icon" style="background:rgba(14,165,233,0.1)"><i class="fas fa-layer-group" style="color:#0ea5e9"></i></div>
      <div>
        <div class="num"><?= number_format($totalTemplates) ?></div>
        <div class="label">Templates</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="icon" style="background:rgba(236,72,153,0.1)"><i class="fas fa-envelope-open-text" style="color:#ec4899"></i></div>
      <div>
        <div class="num"><?= number_format($totalLetters) ?></div>
        <div class="label">Cover Letters</div>
      </div>
    </div>
  </div>

  <!-- Two Column Layout -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.2rem">
    <!-- Recent Candidates -->
    <div class="card">
      <div class="card-header">
        <div class="card-title"><i class="fas fa-users" style="color:#6366f1"></i> Recent Candidates</div>
        <a href="candidates.php" class="btn-sm btn-secondary" style="text-decoration:none">View All</a>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Joined</th></tr></thead>
          <tbody>
          <?php if(empty($recentCandidates)): ?>
            <tr><td colspan="3" style="text-align:center;color:#94a3b8;padding:2rem">No candidates yet</td></tr>
          <?php else: foreach($recentCandidates as $c): ?>
            <tr>
              <td>
                <div style="display:flex;align-items:center;gap:0.6rem">
                  <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center;color:#fff;font-size:0.78rem;font-weight:700;flex-shrink:0">
                    <?= strtoupper(substr($c['first_name']??'C',0,1)) ?>
                  </div>
                  <span style="font-weight:600;color:#1e293b"><?= htmlspecialchars(trim($c['first_name'].' '.$c['last_name'])) ?></span>
                </div>
              </td>
              <td style="color:#64748b;font-size:0.82rem"><?= htmlspecialchars($c['email']) ?></td>
              <td style="color:#94a3b8;font-size:0.79rem"><?= date('M d, Y', strtotime($c['created_at'])) ?></td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Recent CVs -->
    <div class="card">
      <div class="card-header">
        <div class="card-title"><i class="fas fa-file-lines" style="color:#10b981"></i> Recent CVs</div>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Candidate</th><th>CV Title</th><th>Created</th></tr></thead>
          <tbody>
          <?php if(empty($recentCvs)): ?>
            <tr><td colspan="3" style="text-align:center;color:#94a3b8;padding:2rem">No CVs yet</td></tr>
          <?php else: foreach($recentCvs as $cv): ?>
            <tr>
              <td style="font-weight:600;color:#1e293b"><?= htmlspecialchars($cv['cand_name']) ?></td>
              <td style="color:#64748b"><?= htmlspecialchars($cv['title'] ?? 'My CV') ?></td>
              <td style="color:#94a3b8;font-size:0.79rem"><?= date('M d, Y', strtotime($cv['created_at'])) ?></td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Quick Action Cards -->
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-top:0.4rem">
    <a href="templates_manage.php" style="text-decoration:none">
      <div class="stat-card" style="flex-direction:column;align-items:flex-start;gap:0.8rem;cursor:pointer">
        <div class="icon" style="background:rgba(99,102,241,0.1)"><i class="fas fa-layer-group" style="color:#6366f1"></i></div>
        <div>
          <div style="font-weight:700;color:#1e293b;font-size:0.95rem">Template Manager</div>
          <div style="color:#64748b;font-size:0.8rem;margin-top:0.2rem">Add, edit or remove resume templates</div>
        </div>
      </div>
    </a>
    <a href="settings.php" style="text-decoration:none">
      <div class="stat-card" style="flex-direction:column;align-items:flex-start;gap:0.8rem;cursor:pointer">
        <div class="icon" style="background:rgba(245,158,11,0.1)"><i class="fas fa-cog" style="color:#f59e0b"></i></div>
        <div>
          <div style="font-weight:700;color:#1e293b;font-size:0.95rem">System Settings</div>
          <div style="color:#64748b;font-size:0.8rem;margin-top:0.2rem">Configure site settings and options</div>
        </div>
      </div>
    </a>
    <a href="admins.php" style="text-decoration:none">
      <div class="stat-card" style="flex-direction:column;align-items:flex-start;gap:0.8rem;cursor:pointer">
        <div class="icon" style="background:rgba(16,185,129,0.1)"><i class="fas fa-user-shield" style="color:#10b981"></i></div>
        <div>
          <div style="font-weight:700;color:#1e293b;font-size:0.95rem">Admin Users</div>
          <div style="color:#64748b;font-size:0.8rem;margin-top:0.2rem">Manage admin accounts and roles</div>
        </div>
      </div>
    </a>
  </div>
</div>
<?php require_once 'includes/footer.php'; ?>
