<?php
$pageTitle = 'Reports';
require_once 'includes/header.php';

// CSV Export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    try {
        $stmt = $db->query("
            SELECT CONCAT(c.first_name,' ',c.last_name) as full_name, c.email, c.phone, c.city,
                   COUNT(DISTINCT v.id) as total_cvs,
                   COUNT(DISTINCT d.id) as total_downloads,
                   c.created_at as registered_at
            FROM candidates c
            LEFT JOIN cvs v ON c.id = v.candidate_id
            LEFT JOIN download_history d ON c.id = d.user_id
            GROUP BY c.id
            ORDER BY c.created_at DESC
        ");
        $rows = $stmt->fetchAll();
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="candidates_report_' . date('Y-m-d') . '.csv"');
        $fp = fopen('php://output', 'w');
        fputcsv($fp, ['Name', 'Email', 'Phone', 'City', 'Total CVs', 'Total Downloads', 'Registered Date']);
        foreach ($rows as $row) fputcsv($fp, array_values($row));
        fclose($fp);
    } catch(Exception $e) {}
    exit;
}

try { $totalCandidates = $db->query("SELECT COUNT(*) FROM candidates")->fetchColumn(); } catch(Exception $e) { $totalCandidates = 0; }
try { $totalCvs        = $db->query("SELECT COUNT(*) FROM cvs")->fetchColumn(); } catch(Exception $e) { $totalCvs = 0; }
try { $totalDownloads  = $db->query("SELECT COUNT(*) FROM download_history")->fetchColumn(); } catch(Exception $e) { $totalDownloads = 0; }
try { $totalTemplates  = $db->query("SELECT COUNT(*) FROM downloadable_templates WHERE is_active=1")->fetchColumn(); } catch(Exception $e) { $totalTemplates = 0; }
try { $totalCategories = $db->query("SELECT COUNT(*) FROM template_categories")->fetchColumn(); } catch(Exception $e) { $totalCategories = 0; }
$avgCvsPerUser = $totalCandidates > 0 ? round($totalCvs / $totalCandidates, 1) : 0;

try {
    $recentCandidates = $db->query("
        SELECT c.*, COUNT(v.id) as cv_count
        FROM candidates c
        LEFT JOIN cvs v ON c.id = v.candidate_id
        GROUP BY c.id ORDER BY c.created_at DESC LIMIT 10
    ")->fetchAll();
} catch(Exception $e) { $recentCandidates = []; }

try {
    $topDownloaders = $db->query("
        SELECT CONCAT(c.first_name,' ',c.last_name) as full_name, c.email, COUNT(d.id) as downloads
        FROM download_history d
        JOIN candidates c ON d.user_id = c.id
        GROUP BY c.id ORDER BY downloads DESC LIMIT 10
    ")->fetchAll();
} catch(Exception $e) { $topDownloaders = []; }

try {
    $popularTemplates = $db->query("
        SELECT t.title, COUNT(d.id) as downloads, t.file_type
        FROM downloadable_templates t
        LEFT JOIN download_history d ON d.template_id = t.id
        GROUP BY t.id ORDER BY downloads DESC LIMIT 8
    ")->fetchAll();
} catch(Exception $e) { $popularTemplates = []; }

try {
    $monthlyReg = $db->query("
        SELECT DATE_FORMAT(created_at, '%b %Y') as month, COUNT(*) as cnt
        FROM candidates
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
        ORDER BY MIN(created_at)
    ")->fetchAll();
} catch(Exception $e) { $monthlyReg = []; }
?>

<style>
.rpt-grid-3col { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1.2rem; margin-bottom: 1.2rem; }
.rpt-grid-2col { display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem; margin-bottom: 1.2rem; }
.rpt-grid-left-wide { display: grid; grid-template-columns: 2fr 1fr; gap: 1.2rem; margin-bottom: 1.2rem; }
.rpt-card { background:#fff; border-radius:16px; border:1px solid #e8ecf0; box-shadow:0 2px 12px rgba(0,0,0,0.06); overflow:hidden; }
.rpt-card-header { background:#f8fafc; border-bottom:1px solid #f1f5f9; padding:0.9rem 1.2rem; display:flex; align-items:center; justify-content:space-between; }
.rpt-card-title { font-weight:700; font-size:0.9rem; color:#1e293b; display:flex; align-items:center; gap:0.45rem; }
.rpt-stat { background:#fff; border-radius:14px; border:1px solid #e8ecf0; box-shadow:0 2px 10px rgba(0,0,0,0.05); padding:1.2rem 1.3rem; display:flex; align-items:center; gap:1rem; }
.rpt-stat .icon { width:46px; height:46px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.2rem; flex-shrink:0; }
.rpt-stat .num { font-size:1.75rem; font-weight:800; color:#1e293b; line-height:1; font-family:'Sora',sans-serif; }
.rpt-stat .lbl { font-size:0.76rem; color:#64748b; margin-top:0.2rem; font-weight:500; }
.rpt-table { width:100%; border-collapse:collapse; }
.rpt-table th { background:#f8fafc; color:#64748b; font-size:0.75rem; font-weight:700; text-transform:uppercase; letter-spacing:0.05em; padding:0.65rem 1rem; text-align:left; border-bottom:1px solid #f1f5f9; }
.rpt-table td { padding:0.8rem 1rem; border-bottom:1px solid #f8fafc; font-size:0.85rem; color:#334155; vertical-align:middle; }
.rpt-table tr:last-child td { border-bottom:none; }
.rpt-table tr:hover td { background:#fafbff; }
.rpt-bar-wrap { padding:1.1rem 1.3rem; }
.rpt-bar-row { margin-bottom:0.85rem; }
.rpt-bar-row:last-child { margin-bottom:0; }
.rpt-bar-meta { display:flex; justify-content:space-between; margin-bottom:0.3rem; }
.rpt-bar-label { font-size:0.79rem; color:#64748b; }
.rpt-bar-val { font-size:0.79rem; font-weight:700; color:#6366f1; }
.rpt-bar-track { background:#f1f5f9; border-radius:4px; height:7px; overflow:hidden; }
.rpt-bar-fill { background:linear-gradient(90deg,#6366f1,#8b5cf6); height:100%; border-radius:4px; transition:width 0.4s; }
.rank-num { font-family:'Sora',sans-serif; font-weight:800; font-size:0.9rem; }
.empty-state { text-align:center; padding:2.5rem 1rem; color:#94a3b8; }
.empty-state i { font-size:2rem; display:block; margin-bottom:0.75rem; opacity:0.3; }
</style>

<div class="topbar">
    <div class="page-title"><i class="fas fa-chart-bar" style="color:var(--accent)"></i> Reports & Analytics</div>
    <div class="topbar-actions">
        <a href="?export=csv" class="topbar-btn primary"><i class="fas fa-file-csv"></i> Export CSV</a>
    </div>
</div>

<div class="content">

    <!-- Stats Row -->
    <div class="rpt-grid-3col" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr))">
        <div class="rpt-stat" style="border-left:3px solid #6366f1">
            <div class="icon" style="background:rgba(99,102,241,0.1);color:#6366f1"><i class="fas fa-users"></i></div>
            <div><div class="num"><?= $totalCandidates ?></div><div class="lbl">Total Candidates</div></div>
        </div>
        <div class="rpt-stat" style="border-left:3px solid #0ea5e9">
            <div class="icon" style="background:rgba(14,165,233,0.1);color:#0ea5e9"><i class="fas fa-file-lines"></i></div>
            <div><div class="num"><?= $totalCvs ?></div><div class="lbl">CVs Created</div></div>
        </div>
        <div class="rpt-stat" style="border-left:3px solid #10b981">
            <div class="icon" style="background:rgba(16,185,129,0.1);color:#10b981"><i class="fas fa-download"></i></div>
            <div><div class="num"><?= $totalDownloads ?></div><div class="lbl">Total Downloads</div></div>
        </div>
        <div class="rpt-stat" style="border-left:3px solid #f59e0b">
            <div class="icon" style="background:rgba(245,158,11,0.1);color:#f59e0b"><i class="fas fa-layer-group"></i></div>
            <div><div class="num"><?= $totalTemplates ?></div><div class="lbl">Active Templates</div></div>
        </div>
        <div class="rpt-stat" style="border-left:3px solid #8b5cf6">
            <div class="icon" style="background:rgba(139,92,246,0.1);color:#8b5cf6"><i class="fas fa-chart-line"></i></div>
            <div><div class="num"><?= $avgCvsPerUser ?></div><div class="lbl">Avg CVs / User</div></div>
        </div>
        <div class="rpt-stat" style="border-left:3px solid #06b6d4">
            <div class="icon" style="background:rgba(6,182,212,0.1);color:#06b6d4"><i class="fas fa-tags"></i></div>
            <div><div class="num"><?= $totalCategories ?></div><div class="lbl">Categories</div></div>
        </div>
    </div>

    <!-- Row 2: Recent Registrations + Monthly Chart -->
    <div class="rpt-grid-left-wide">
        <!-- Recent Registrations -->
        <div class="rpt-card">
            <div class="rpt-card-header">
                <div class="rpt-card-title"><i class="fas fa-user-plus" style="color:#6366f1"></i> Recent Registrations</div>
                <a href="candidates.php" style="font-size:0.78rem;color:#6366f1;font-weight:600;text-decoration:none">View All →</a>
            </div>
            <?php if (empty($recentCandidates)): ?>
            <div class="empty-state"><i class="fas fa-users"></i>No candidates yet</div>
            <?php else: ?>
            <div style="overflow-x:auto">
            <table class="rpt-table">
                <thead><tr><th>Candidate</th><th>City</th><th>CVs</th><th>Joined</th></tr></thead>
                <tbody>
                <?php foreach ($recentCandidates as $c): ?>
                <tr>
                    <td>
                        <div style="font-weight:600;font-size:0.86rem;color:#1e293b"><?= htmlspecialchars(trim($c['first_name'].' '.$c['last_name'])) ?></div>
                        <div style="font-size:0.75rem;color:#94a3b8"><?= htmlspecialchars($c['email']) ?></div>
                    </td>
                    <td style="color:#64748b"><?= htmlspecialchars($c['city'] ?? '—') ?></td>
                    <td><span style="font-family:'Sora',sans-serif;font-weight:800;color:#6366f1;font-size:1rem"><?= $c['cv_count'] ?></span></td>
                    <td style="font-size:0.78rem;color:#94a3b8;white-space:nowrap"><?= formatDate($c['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php endif; ?>
        </div>

        <!-- Monthly Registrations -->
        <div class="rpt-card">
            <div class="rpt-card-header">
                <div class="rpt-card-title"><i class="fas fa-calendar-alt" style="color:#8b5cf6"></i> Monthly Sign-ups</div>
            </div>
            <?php if (empty($monthlyReg)): ?>
            <div class="empty-state"><i class="fas fa-calendar"></i>No data yet</div>
            <?php else: ?>
            <div class="rpt-bar-wrap">
                <?php
                $maxReg = max(array_column($monthlyReg, 'cnt')) ?: 1;
                foreach ($monthlyReg as $m): ?>
                <div class="rpt-bar-row">
                    <div class="rpt-bar-meta">
                        <span class="rpt-bar-label"><?= htmlspecialchars($m['month']) ?></span>
                        <span class="rpt-bar-val"><?= $m['cnt'] ?></span>
                    </div>
                    <div class="rpt-bar-track">
                        <div class="rpt-bar-fill" style="width:<?= round(($m['cnt']/$maxReg)*100) ?>%"></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Row 3: Top Downloaders + Popular Templates -->
    <div class="rpt-grid-2col">
        <!-- Top Downloaders -->
        <div class="rpt-card">
            <div class="rpt-card-header">
                <div class="rpt-card-title"><i class="fas fa-trophy" style="color:#f59e0b"></i> Top Downloaders</div>
            </div>
            <?php if (empty($topDownloaders)): ?>
            <div class="empty-state"><i class="fas fa-download"></i>No downloads yet</div>
            <?php else: ?>
            <div style="overflow-x:auto">
            <table class="rpt-table">
                <thead><tr><th style="width:40px">#</th><th>Candidate</th><th>Downloads</th></tr></thead>
                <tbody>
                <?php foreach ($topDownloaders as $i => $d):
                    $rankColor = $i===0 ? '#f59e0b' : ($i===1 ? '#94a3b8' : ($i===2 ? '#cd7f32' : '#cbd5e1'));
                ?>
                <tr>
                    <td><span class="rank-num" style="color:<?= $rankColor ?>"><?= $i+1 ?></span></td>
                    <td>
                        <div style="font-weight:600;font-size:0.86rem;color:#1e293b"><?= htmlspecialchars($d['full_name']) ?></div>
                        <div style="font-size:0.75rem;color:#94a3b8"><?= htmlspecialchars($d['email']) ?></div>
                    </td>
                    <td>
                        <span style="font-family:'Sora',sans-serif;font-weight:800;font-size:1.05rem;color:#10b981"><?= $d['downloads'] ?></span>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php endif; ?>
        </div>

        <!-- Popular Templates -->
        <div class="rpt-card">
            <div class="rpt-card-header">
                <div class="rpt-card-title"><i class="fas fa-fire" style="color:#ef4444"></i> Popular Templates</div>
            </div>
            <?php if (empty($popularTemplates)): ?>
            <div class="empty-state"><i class="fas fa-layer-group"></i>No template data yet</div>
            <?php else: ?>
            <div style="overflow-x:auto">
            <table class="rpt-table">
                <thead><tr><th>Template</th><th>Type</th><th>Downloads</th></tr></thead>
                <tbody>
                <?php foreach ($popularTemplates as $t): ?>
                <tr>
                    <td style="font-weight:600;font-size:0.86rem;color:#1e293b"><?= htmlspecialchars($t['title']) ?></td>
                    <td>
                        <span style="background:rgba(99,102,241,0.1);color:#6366f1;padding:0.2rem 0.55rem;border-radius:20px;font-size:0.7rem;font-weight:700">
                            <?= strtoupper($t['file_type']) ?>
                        </span>
                    </td>
                    <td><span style="font-family:'Sora',sans-serif;font-weight:800;color:#6366f1"><?= $t['downloads'] ?></span></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php require_once 'includes/footer.php'; ?>
