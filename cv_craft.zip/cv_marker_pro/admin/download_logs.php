<?php
$pageTitle = 'Download Logs';
require_once 'includes/header.php';
$logs = $db->query("SELECT dh.*, t.title as tpl_title, CONCAT(c.first_name,' ',c.last_name) as user_name, c.email 
    FROM download_history dh 
    JOIN downloadable_templates t ON dh.template_id=t.id 
    JOIN candidates c ON dh.user_id=c.id 
    ORDER BY dh.downloaded_at DESC LIMIT 200")->fetchAll();
?>
<div class="topbar"><span class="topbar-title"><i class="fas fa-history" style="color:#10b981"></i> Download Logs</span></div>
<div class="content-area">
    <div class="card" style="background:#1e293b;border:1px solid rgba(255,255,255,0.07);border-radius:14px;overflow:hidden">
    <div class="table-responsive">
    <table class="table table-dark-custom mb-0">
        <thead><tr><th>#</th><th>User</th><th>Email</th><th>Template</th><th>Date</th><th>IP</th></tr></thead>
        <tbody>
        <?php foreach($logs as $i=>$log): ?>
        <tr>
            <td><?= $i+1 ?></td>
            <td><?= htmlspecialchars($log['user_name']) ?></td>
            <td><?= htmlspecialchars($log['email']) ?></td>
            <td><?= htmlspecialchars($log['tpl_title']) ?></td>
            <td><?= formatDate($log['downloaded_at'], 'd M Y H:i') ?></td>
            <td><small style="color:#64748b"><?= $log['ip_address'] ?></small></td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($logs)): ?><tr><td colspan="6" style="text-align:center;color:#475569;padding:2rem">No download logs yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
    </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
