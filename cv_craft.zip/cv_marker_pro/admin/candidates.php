<?php
$pageTitle = 'Candidates';
require_once 'includes/header.php';

$search = sanitize($_GET['search'] ?? '');
$action = $_GET['action'] ?? '';
$candidateId = (int)($_GET['id'] ?? 0);
if ($candidateId && in_array($action, ['block','unblock','delete'], true)) {
    if ($action === 'delete') {
        $db->prepare("DELETE FROM candidates WHERE id=?")->execute([$candidateId]);
        setFlash('danger', 'Candidate deleted successfully.');
    } else {
        $active = $action === 'unblock' ? 1 : 0;
        $db->prepare("UPDATE candidates SET is_active=? WHERE id=?")->execute([$active, $candidateId]);
        setFlash('success', $active ? 'Candidate unblocked.' : 'Candidate blocked.');
    }
    header('Location: candidates.php');
    exit;
}
$params = [];
$where = "WHERE 1=1";
if ($search) {
    $where .= " AND (c.first_name LIKE ? OR c.last_name LIKE ? OR c.email LIKE ? OR c.username LIKE ?)";
    $params = ["%$search%", "%$search%", "%$search%", "%$search%"];
}

$stmt = $db->prepare("
    SELECT c.*, CONCAT(c.first_name,' ',c.last_name) as full_name,
           COUNT(a.id) as app_count, MAX(s.final_score) as best_score
    FROM candidates c
    LEFT JOIN cv_applications a ON c.id = a.candidate_id
    LEFT JOIN cv_scores s ON a.id = s.application_id
    $where GROUP BY c.id ORDER BY c.created_at DESC
");
$stmt->execute($params);
$candidates = $stmt->fetchAll();
?>
<div class="topbar">
    <div class="page-title"><i class="fas fa-users" style="color:var(--primary)"></i> Candidates</div>
</div>
<div class="content-area p-4">
    <div class="card mb-3 p-3">
        <form method="GET" class="d-flex gap-2">
            <input type="text" name="search" class="form-control" placeholder="Search name, email, username..." value="<?= htmlspecialchars($search) ?>" style="max-width:360px">
            <button type="submit" class="btn btn-primary"><i class="fas fa-search me-1"></i>Search</button>
            <?php if($search):?><a href="candidates.php" class="btn btn-outline-secondary">Clear</a><?php endif;?>
        </form>
    </div>
    <div class="card">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead><tr>
                    <th>Candidate</th><th>Username</th><th>City</th>
                    <th>Applications</th><th>Best Score</th><th>Status</th><th>Joined</th><th>Action</th>
                </tr></thead>
                <tbody>
                <?php if(empty($candidates)):?>
                    <tr><td colspan="8" class="text-center py-4" style="color:#64748b">No candidates found.</td></tr>
                <?php else: foreach($candidates as $c):?>
                    <tr>
                        <td>
                            <div class="fw-semibold"><?= htmlspecialchars($c['full_name']) ?></div>
                            <div style="font-size:0.78rem;color:#64748b"><?= htmlspecialchars($c['email']) ?></div>
                            <?php if($c['phone']):?><div style="font-size:0.75rem;color:#64748b"><?= htmlspecialchars($c['phone']) ?></div><?php endif;?>
                        </td>
                        <td><code style="color:#818cf8;font-size:0.82rem">@<?= htmlspecialchars($c['username']) ?></code></td>
                        <td style="font-size:0.85rem"><?= htmlspecialchars($c['city']??'—') ?></td>
                        <td><a href="applications.php?search=<?= urlencode($c['email']) ?>" style="color:var(--primary);font-weight:700"><?= $c['app_count'] ?></a></td>
                        <td>
                            <?php if($c['best_score']):?>
                                <?php $cl = $c['best_score']>=60?'success':($c['best_score']>=45?'warning':'danger');?>
                                <span class="badge text-bg-<?= $cl ?>"><?= number_format($c['best_score'],1) ?></span>
                            <?php else:?><span style="color:#475569;font-size:0.8rem">N/A</span><?php endif;?>
                        </td>
                        <td><?= (int)$c['is_active'] ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-danger">Blocked</span>' ?></td>
                        <td style="font-size:0.8rem;color:#64748b"><?= formatDate($c['created_at']) ?></td>
                        <td>
                            <div class="d-flex gap-1 flex-wrap">
                                <a href="applications.php?search=<?= urlencode($c['email']) ?>" class="btn btn-sm btn-outline-secondary"><i class="fas fa-eye"></i> Apps</a>
                                <?php if((int)$c['is_active']): ?>
                                <a href="?action=block&id=<?= $c['id'] ?>" class="btn btn-sm btn-warning" onclick="return confirm('Block this candidate?')"><i class="fas fa-ban"></i></a>
                                <?php else: ?>
                                <a href="?action=unblock&id=<?= $c['id'] ?>" class="btn btn-sm btn-success"><i class="fas fa-check"></i></a>
                                <?php endif; ?>
                                <a href="?action=delete&id=<?= $c['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this candidate and related data?')"><i class="fas fa-trash"></i></a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif;?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
