<?php
const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';
const DB_NAME = 'cv_marker_db';
const SITE_NAME = 'CV Craft';
const SESSION_TIMEOUT_SECONDS = 60;

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$script = $_SERVER['SCRIPT_NAME'] ?? '';
$parts = explode('/', trim($script, '/'));
$firstPart = $parts[0] ?? '';
$base = '';
if ($firstPart !== '' && !str_contains($firstPart, '.') && !in_array($firstPart, ['admin', 'candidate', 'ajax', 'includes'], true)) {
    $base = '/' . $firstPart;
}

define('SITE_URL', $protocol . '://' . $host . $base);
define('ADMIN_URL', SITE_URL . '/admin');
define('CANDIDATE_URL', SITE_URL . '/candidate');
define('UPLOAD_PATH', __DIR__ . '/../uploads/cvs/');
define('UPLOAD_URL', SITE_URL . '/uploads/cvs/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024);
define('ALLOWED_TYPES', ['pdf', 'doc', 'docx']);

ini_set('session.cookie_httponly', '1');
ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_samesite', 'Lax');
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $protocol === 'https',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            die('<div style="font-family:sans-serif;padding:2rem;background:#0f172a;color:#fca5a5;min-height:100vh"><h2>Database Error</h2><p>' . htmlspecialchars($e->getMessage()) . '</p><p style="color:#94a3b8;margin-top:1rem">Check: XAMPP MySQL running + cv_marker_db imported</p></div>');
        }
        ensureAppTables($pdo);
    }
    return $pdo;
}

function ensureAppTables(PDO $pdo) {
    static $done = false;
    if ($done) return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS employers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_name VARCHAR(150) NOT NULL,
        contact_name VARCHAR(120) NOT NULL,
        email VARCHAR(120) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        phone VARCHAR(30) NULL,
        location VARCHAR(120) NULL,
        website VARCHAR(255) NULL,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS cvs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        candidate_id INT NOT NULL,
        title VARCHAR(150) NOT NULL DEFAULT 'Untitled CV',
        template VARCHAR(50) NOT NULL DEFAULT 'clean',
        data_json LONGTEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_candidate (candidate_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS cover_letters (
        id INT AUTO_INCREMENT PRIMARY KEY,
        candidate_id INT NOT NULL,
        title VARCHAR(150) NOT NULL DEFAULT 'Cover Letter',
        applicant_name VARCHAR(150) NOT NULL,
        company VARCHAR(150) NOT NULL,
        position VARCHAR(150) NOT NULL,
        template VARCHAR(50) NOT NULL DEFAULT 'formal',
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_candidate (candidate_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    addColumnIfMissing($pdo, 'job_positions', 'category', "VARCHAR(100) NULL AFTER department");
    addColumnIfMissing($pdo, 'job_positions', 'location', "VARCHAR(120) NULL AFTER category");
    addColumnIfMissing($pdo, 'job_positions', 'employer_id', "INT NULL AFTER created_by");
    $done = true;
}

function addColumnIfMissing(PDO $pdo, $table, $column, $definition) {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
        $stmt->execute([$column]);
        if (!$stmt->fetch()) {
            $pdo->exec("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
        }
    } catch (Exception $e) {}
}

function sanitize($d) { return htmlspecialchars(strip_tags(trim((string)$d)), ENT_QUOTES, 'UTF-8'); }
function generateToken($l = 32) { return bin2hex(random_bytes($l)); }
function generateApplicationId() { return 'APP-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8)); }
function hashPassword($p) { return password_hash($p, PASSWORD_BCRYPT, ['cost' => 12]); }
function verifyPassword($p, $h) { return password_verify($p, $h); }
function setFlash($t, $m) { $_SESSION['flash'] = ['type' => $t, 'message' => $m]; }
function getFlash() { if (isset($_SESSION['flash'])) { $f = $_SESSION['flash']; unset($_SESSION['flash']); return $f; } return null; }
function isCandidateLoggedIn() { return !empty($_SESSION['candidate_id']); }
function isAdminLoggedIn() { return !empty($_SESSION['admin_id']); }
function isEmployerLoggedIn() { return !empty($_SESSION['employer_id']); }
function isLoggedIn() { return isCandidateLoggedIn() || isAdminLoggedIn() || isEmployerLoggedIn(); }

function resetSessionIdentity() {
    unset($_SESSION['candidate_id'], $_SESSION['candidate_name'], $_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['admin_role'], $_SESSION['employer_id'], $_SESSION['employer_name']);
}

function destroySessionAndRedirect($message = 'Your session expired. Please login again.') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    session_start();
    setFlash('warning', $message);
    header('Location: ' . SITE_URL . '/login.php');
    exit;
}

function markAuthenticatedSession() {
    session_regenerate_id(true);
    $_SESSION['last_activity'] = time();
}

function getCurrentRequestUrl() {
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    return $uri;
}

function rememberReturnTo() {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method === 'GET') {
        $_SESSION['redirect_after_login'] = getCurrentRequestUrl();
    }
}

function redirectAfterLogin($default) {
    $target = $_SESSION['redirect_after_login'] ?? $default;
    unset($_SESSION['redirect_after_login']);
    if (!is_string($target) || $target === '' || preg_match('/^https?:\/\//i', $target)) {
        $target = $default;
    }
    header('Location: ' . $target);
    exit;
}

function requireCandidate() {
    if (!isCandidateLoggedIn()) {
        rememberReturnTo();
        setFlash('warning', 'Please login as a candidate to continue.');
        header('Location: ' . SITE_URL . '/login.php');
        exit;
    }
}

function requireAdmin() {
    if (!isAdminLoggedIn()) {
        rememberReturnTo();
        setFlash('warning', 'Please login as an admin to continue.');
        header('Location: ' . SITE_URL . '/login.php');
        exit;
    }
}

function requireEmployer() {
    if (!isEmployerLoggedIn()) {
        rememberReturnTo();
        setFlash('warning', 'Please login as an employer to continue.');
        header('Location: ' . SITE_URL . '/employer/login.php');
        exit;
    }
}

function logActivity($ut, $uid, $action, $desc = '') {
    try {
        $db = getDB();
        $db->prepare('INSERT INTO activity_logs(user_type,user_id,action,description,ip_address) VALUES(?,?,?,?,?)')->execute([$ut, $uid, $action, $desc, $_SERVER['REMOTE_ADDR'] ?? '']);
    } catch (Exception $e) {}
}

function createNotification($cid, $aid, $type, $title, $msg) {
    try {
        $db = getDB();
        $db->prepare('INSERT INTO notifications(candidate_id,application_id,type,title,message) VALUES(?,?,?,?,?)')->execute([$cid, $aid, $type, $title, $msg]);
    } catch (Exception $e) {}
}

function formatDate($d, $f = 'd M Y') { return date($f, strtotime($d)); }

function getStatusBadge($s) {
    $b = ['pending' => 'warning', 'under_review' => 'info', 'scored' => 'primary', 'shortlisted' => 'success', 'rejected' => 'danger', 'hired' => 'dark'];
    $c = $b[$s] ?? 'secondary';
    return '<span class="badge bg-' . $c . '">' . ucfirst(str_replace('_', ' ', $s)) . '</span>';
}

function getCandidateName($cand) {
    $name = trim(($cand['first_name'] ?? '') . ' ' . ($cand['last_name'] ?? ''));
    if ($name !== '') return $name;
    return $cand['full_name'] ?? 'Candidate';
}

function currentScriptPath() {
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $basePath = parse_url(SITE_URL, PHP_URL_PATH) ?: '';
    if ($basePath && strpos($script, $basePath) === 0) {
        $script = substr($script, strlen($basePath));
    }
    return '/' . ltrim($script, '/');
}

function enforceRouteProtection() {
    $path = currentScriptPath();
    $allowed = ['/login.php', '/candidate/login.php', '/candidate/register.php', '/admin/login.php', '/candidate/logout.php', '/admin/logout.php', '/employer/login.php', '/employer/register.php', '/employer/logout.php'];
    if (in_array($path, $allowed, true) || strpos($path, '/includes/') === 0) {
        return;
    }
    if (isLoggedIn()) {
        return;
    }
    if (strpos($path, '/ajax/') === 0) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Please login again.']);
        exit;
    }
    rememberReturnTo();
    setFlash('warning', 'Please login to continue.');
    header('Location: ' . SITE_URL . '/login.php');
    exit;
}

function enforceSessionTimeout() {
    if (!isLoggedIn()) {
        return;
    }
    $last = (int)($_SESSION['last_activity'] ?? 0);
    if ($last > 0 && time() - $last > SESSION_TIMEOUT_SECONDS) {
        destroySessionAndRedirect();
    }
    $_SESSION['last_activity'] = time();
}

enforceSessionTimeout();
enforceRouteProtection();
?>