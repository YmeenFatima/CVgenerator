// ===== CV MARKER PRO - SHARED JS =====
// Version: 4.0 - Enhanced with Real-time Preview & Better Validation

// Toaster System with Auto-dismiss
function showToast(message, type = 'info', duration = 4000) {
    let container = document.getElementById('toaster-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toaster-container';
        container.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px;pointer-events:none;';
        document.body.appendChild(container);
    }
    const icons = { 
        success: 'fa-check-circle', 
        danger: 'fa-times-circle', 
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle', 
        warning: 'fa-exclamation-triangle' 
    };
    const colors = {
        success: 'rgba(16, 185, 129, 0.95)',
        danger: 'rgba(239, 68, 68, 0.95)',
        error: 'rgba(239, 68, 68, 0.95)',
        info: 'rgba(59, 130, 246, 0.95)',
        warning: 'rgba(245, 158, 11, 0.95)'
    };
    const toast = document.createElement('div');
    toast.className = `toaster-item ${type}`;
    toast.style.cssText = `
        background:${colors[type] || colors.info};
        color:white;
        padding:12px 16px;
        border-radius:8px;
        display:flex;
        align-items:center;
        gap:10px;
        font-size:0.9rem;
        box-shadow:0 4px 12px rgba(0,0,0,0.15);
        animation:slideInRight 0.3s ease;
        pointer-events:auto;
    `;
    toast.innerHTML = `
        <i class="fas ${icons[type] || icons.info}" style="font-size:1.1rem;"></i>
        <span>${message}</span>
        <button class="toast-close" onclick="this.parentElement.remove()" style="background:none;border:none;color:white;cursor:pointer;font-size:1.1rem;padding:0;margin-left:auto;">
            <i class="fas fa-times"></i>
        </button>
    `;
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.animation = 'slideOutRight 0.3s ease forwards';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// Password Eye Toggle - Enhanced
function initPasswordToggle() {
    document.querySelectorAll('.btn-eye, .password-toggle').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const input = this.closest('.input-password-wrap') ? 
                         this.closest('.input-password-wrap').querySelector('input') :
                         this.previousElementSibling;
            if (!input) return;
            const isPass = input.type === 'password';
            input.type = isPass ? 'text' : 'password';
            const icon = this.querySelector('i');
            if (icon) {
                icon.className = isPass ? 'fas fa-eye-slash' : 'fas fa-eye';
            }
            this.classList.toggle('active', !isPass);
        });
    });
}

// Dark Mode
function initDarkMode() {
    const toggle = document.getElementById('darkToggle');
    const saved = localStorage.getItem('darkMode') !== 'false';
    if (saved) {
        document.body.classList.add('dark-mode');
        if (toggle) toggle.classList.add('active');
    }
    if (toggle) {
        toggle.addEventListener('click', () => {
            const isDark = document.body.classList.toggle('dark-mode');
            toggle.classList.toggle('active', isDark);
            localStorage.setItem('darkMode', isDark);
        });
    }
}

function initThemeSwitcher() {
    const theme = localStorage.getItem('cvTheme') || 'blue';
    applyTheme(theme);
    document.querySelectorAll('#themeSwitcher').forEach(select => {
        select.value = theme;
        select.addEventListener('change', function() {
            applyTheme(this.value);
            localStorage.setItem('cvTheme', this.value);
            showToast('Theme updated', 'success', 1800);
        });
    });
}

function applyTheme(theme) {
    document.body.classList.remove('theme-blue', 'theme-dark', 'theme-purple', 'theme-green');
    document.body.classList.add('theme-' + theme);
}

// Real-time Form Validation - Enhanced
function initFormValidation() {
    document.querySelectorAll('[data-validate]').forEach(input => {
        input.addEventListener('input', function() {
            validateField(this);
        });
        input.addEventListener('blur', function() {
            validateField(this);
        });
        input.addEventListener('focus', function() {
            this.classList.remove('is-invalid-custom');
            const fb = this.nextElementSibling;
            if (fb && fb.classList.contains('invalid-feedback-custom')) fb.remove();
        });
    });
}

function validateField(input) {
    const rules = input.dataset.validate ? input.dataset.validate.split('|') : [];
    let error = '';
    
    for (const rule of rules) {
        if (rule === 'required' && !input.value.trim()) { 
            error = '⚠ This field is required.'; 
            break; 
        }
        if (rule === 'email' && input.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) { 
            error = '⚠ Enter a valid email.'; 
            break; 
        }
        if (rule === 'phone' && input.value && !/^\d{10,15}$/.test(input.value.replace(/\D/g, ''))) { 
            error = '⚠ Enter a valid phone number.'; 
            break; 
        }
        if (rule.startsWith('min:')) {
            const min = parseInt(rule.split(':')[1]);
            if (input.value.length < min) { 
                error = `⚠ Minimum ${min} characters required.`; 
                break; 
            }
        }
        if (rule.startsWith('max:')) {
            const max = parseInt(rule.split(':')[1]);
            if (input.value.length > max) { 
                error = `⚠ Maximum ${max} characters allowed.`; 
                break; 
            }
        }
    }
    
    const fb = input.nextElementSibling;
    if (fb && fb.classList.contains('invalid-feedback-custom')) fb.remove();
    
    if (error) {
        input.classList.add('is-invalid-custom');
        const div = document.createElement('div');
        div.className = 'invalid-feedback-custom';
        div.style.cssText = 'color:#f87171;font-size:0.78rem;margin-top:0.25rem;';
        div.textContent = error;
        input.insertAdjacentElement('afterend', div);
    } else {
        input.classList.remove('is-invalid-custom');
    }
}

// Sidebar mobile toggle
function initSidebar() {
    const toggle = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.sidebar');
    if (toggle && sidebar) {
        toggle.addEventListener('click', () => sidebar.classList.toggle('open'));
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        });
    }
}

// Smooth scroll
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', function(e) {
            const target = document.querySelector(this.getAttribute('href'));
            if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
        });
    });
}

// Loading spinner
function showLoader() {
    let l = document.getElementById('global-loader');
    if (!l) {
        l = document.createElement('div');
        l.id = 'global-loader';
        l.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,23,42,0.7);z-index:99998;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)';
        l.innerHTML = '<div style="width:48px;height:48px;border:3px solid rgba(255,255,255,0.1);border-top-color:#6366f1;border-radius:50%;animation:spin 0.8s linear infinite"></div><style>@keyframes spin{to{transform:rotate(360deg)}}</style>';
        document.body.appendChild(l);
    }
    l.style.display = 'flex';
}
function hideLoader() {
    const l = document.getElementById('global-loader');
    if (l) l.style.display = 'none';
}

// Search + filter table
function initTableSearch() {
    const searchInput = document.getElementById('tableSearch');
    if (!searchInput) return;
    searchInput.addEventListener('input', function() {
        const q = this.value.toLowerCase();
        document.querySelectorAll('[data-searchable] tr').forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    });
}

// Confirm delete with modern modal
function confirmDelete(url, msg = 'Are you sure you want to delete this? This action cannot be undone.') {
    if (confirm(msg)) {
        showLoader();
        window.location.href = url;
    }
}

// CV Marker - Auto-save functionality
let cvAutoSaveTimer;
function initCVAutoSave(formSelector = '#cvForm') {
    const form = document.querySelector(formSelector);
    if (!form) return;
    
    form.addEventListener('change', function() {
        clearTimeout(cvAutoSaveTimer);
        cvAutoSaveTimer = setTimeout(() => {
            const formData = new FormData(form);
            fetch(form.action || window.location.pathname, {
                method: 'POST',
                body: formData
            })
            .then(r => r.json())
            .catch(() => {})
            .finally(() => showToast('CV saved automatically', 'success', 3000));
        }, 2000);
    });
}

// CV Preview Sync - Update preview as user types
function initCVPreviewSync() {
    document.querySelectorAll('[data-preview-target]').forEach(input => {
        input.addEventListener('input', function() {
            const target = this.dataset.previewTarget;
            const element = document.querySelector(`[data-preview="${target}"]`);
            if (element) {
                element.textContent = this.value || this.placeholder;
                element.style.display = this.value ? 'block' : 'none';
            }
        });
    });
}

// Real-time PDF Preview
function initPDFPreview() {
    const previewContainer = document.getElementById('cvPreview');
    if (!previewContainer) return;
    
    document.addEventListener('change', function(e) {
        if (e.target.matches('[data-preview-trigger]')) {
            regeneratePreview();
        }
    });
}

function regeneratePreview() {
    const preview = document.getElementById('cvPreview');
    if (preview && window.html2pdf) {
        const element = document.getElementById('cvContent');
        if (element) {
            const opt = {
                margin: 10,
                filename: 'cv.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { orientation: 'portrait', unit: 'mm', format: 'a4' }
            };
            const pdf = html2pdf().set(opt).from(element);
            // Update preview without actually downloading
        }
    }
}

// Add keyframes for animations
function initAnimationStyles() {
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from { transform: translateX(400px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOutRight {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(400px); opacity: 0; }
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    `;
    if (!document.querySelector('style[data-animations]')) {
        style.setAttribute('data-animations', '');
        document.head.appendChild(style);
    }
}

// Init all on DOM ready
document.addEventListener('DOMContentLoaded', function() {
    initAnimationStyles();
    initPasswordToggle();
    initDarkMode();
    initThemeSwitcher();
    initFormValidation();
    initSidebar();
    initSmoothScroll();
    initTableSearch();
    initCVPreviewSync();
    initCVAutoSave();
    
    // Bootstrap tooltips
    if (typeof bootstrap !== 'undefined') {
        document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => new bootstrap.Tooltip(el));
    }
});

// Global error handler
window.addEventListener('error', function(e) {
    console.error('Error:', e);
    showToast('Something went wrong. Please refresh.', 'error', 5000);
});
