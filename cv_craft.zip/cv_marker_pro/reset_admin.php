<?php
require_once 'includes/config.php';
try {
    $db = getDB();
    $hash = password_hash('Admin@123', PASSWORD_BCRYPT);
    $db->prepare("UPDATE admin_users SET password=?,is_active=1 WHERE email='admin@cvmarker.com'")->execute([$hash]);
    echo "<div style='font-family:sans-serif;padding:2rem;background:#0f172a;color:#10b981;min-height:100vh'>
    <h2>✅ Password reset!</h2>
    <p style='color:#94a3b8;margin:1rem 0'>Email: <b style='color:#f1f5f9'>admin@cvmarker.com</b> &nbsp; Password: <b style='color:#f1f5f9'>Admin@123</b></p>
    <a href='admin/dashboard.php' style='color:#6366f1;font-size:1.1rem'>→ Open Admin Panel (No login needed)</a><br><br>
    <small style='color:#475569'>Delete this file after use!</small></div>";
} catch(Exception $e) {
    echo "<p style='color:#fca5a5;font-family:sans-serif;padding:2rem'>Error: ".$e->getMessage()."</p>";
}
