<?php
require_once 'includes/config.php';
$db = getDB();
$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: templates_browse.php'); exit; }

$stmt = $db->prepare("SELECT t.*, c.name as category_name, c.slug as category_slug, c.icon as category_icon 
    FROM downloadable_templates t 
    JOIN template_categories c ON t.category_id=c.id 
    WHERE t.id=? AND t.is_active=1");
$stmt->execute([$id]);
$tpl = $stmt->fetch();
if (!$tpl) { header('Location: templates_browse.php'); exit; }

$isFav = false;
if (isset($_SESSION['candidate_id'])) {
    $fCheck = $db->prepare("SELECT COUNT(*) FROM favorites WHERE user_id=? AND template_id=?");
    $fCheck->execute([$_SESSION['candidate_id'], $id]);
    $isFav = $fCheck->fetchColumn() > 0;
}

// Related templates
$related = $db->prepare("SELECT t.*, c.name as category_name, c.icon as category_icon FROM downloadable_templates t JOIN template_categories c ON t.category_id=c.id WHERE t.category_id=? AND t.id!=? AND t.is_active=1 ORDER BY t.download_count DESC LIMIT 4");
$related->execute([$tpl['category_id'], $id]);
$related = $related->fetchAll();

$tags = $tpl['tags'] ? explode(',', $tpl['tags']) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($tpl['title']) ?> — <?= SITE_NAME ?></title>
<?php include 'includes/assets.php'; ?>
<link href="includes/common.css" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#0a0f1e;color:#e2e8f0;}
.nav-top{position:sticky;top:0;z-index:100;background:rgba(10,15,30,0.95);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);padding:0.8rem 0;}
.nav-inner{max-width:1280px;margin:0 auto;padding:0 2rem;display:flex;align-items:center;justify-content:space-between;}
.brand{display:flex;align-items:center;gap:0.6rem;text-decoration:none;}
.brand-box{width:34px;height:34px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:8px;display:flex;align-items:center;justify-content:center;}
.brand-txt{font-family:'Sora',sans-serif;font-size:1.05rem;font-weight:800;color:#f1f5f9;}
.brand-txt span{color:#6366f1;}
.nav-links{display:flex;align-items:center;gap:1.5rem;}
.nav-links a{color:#94a3b8;font-size:0.85rem;font-weight:500;text-decoration:none;transition:color 0.2s;}
.nav-links a:hover{color:#f1f5f9;}
.nav-btns{display:flex;gap:0.6rem;}
.btn-nav-outline{border:1px solid rgba(255,255,255,0.15);color:#e2e8f0;padding:0.4rem 1rem;border-radius:8px;font-size:0.82rem;font-weight:600;text-decoration:none;}
.btn-nav-primary{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;padding:0.4rem 1.1rem;border-radius:8px;font-size:0.82rem;font-weight:700;text-decoration:none;}

.detail-wrap{max-width:1100px;margin:2rem auto;padding:0 2rem;display:grid;grid-template-columns:1fr 1fr;gap:3rem;}
.preview-col{background:#1e293b;border:1px solid rgba(255,255,255,0.07);border-radius:16px;overflow:hidden;aspect-ratio:3/4;display:flex;align-items:center;justify-content:center;}
.preview-col img{width:100%;height:100%;object-fit:cover;}
.preview-col .ph{font-size:4rem;color:#475569;}
.mock-preview-lg{width:72%;height:82%;background:#f8fafc;border-radius:10px;padding:28px;box-shadow:0 22px 42px rgba(0,0,0,0.25);display:flex;flex-direction:column;gap:11px;}
.mock-preview-lg .bar{height:10px;border-radius:10px;background:#cbd5e1;}
.mock-preview-lg .bar.title{height:22px;width:72%;background:#6366f1;}
.mock-preview-lg .bar.mid{width:84%;}
.mock-preview-lg .bar.short{width:55%;}
.mock-preview-lg .section{height:3px;background:#6366f1;margin:8px 0 3px;}
.info-col{display:flex;flex-direction:column;gap:1.5rem;}
.breadcrumb-bar{display:flex;align-items:center;gap:0.5rem;font-size:0.82rem;color:#64748b;}
.breadcrumb-bar a{color:#6366f1;text-decoration:none;}
.tpl-title{font-family:'Sora',sans-serif;font-size:1.8rem;font-weight:800;color:#f1f5f9;}
.tpl-cat-badge{display:inline-flex;align-items:center;gap:0.4rem;background:rgba(99,102,241,0.12);border:1px solid rgba(99,102,241,0.25);color:#a5b4fc;padding:0.3rem 0.8rem;border-radius:20px;font-size:0.78rem;font-weight:600;}
.tpl-stats{display:flex;gap:1.5rem;flex-wrap:wrap;}
.tpl-stat{display:flex;align-items:center;gap:0.4rem;font-size:0.85rem;color:#94a3b8;}
.tpl-stat i{color:#6366f1;}
.tpl-description{color:#94a3b8;font-size:0.92rem;line-height:1.8;}
.tpl-tags{display:flex;gap:0.4rem;flex-wrap:wrap;}
.tag{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);color:#94a3b8;padding:0.25rem 0.7rem;border-radius:15px;font-size:0.75rem;}
.action-btns{display:flex;gap:1rem;flex-wrap:wrap;}
.btn-download-lg{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;padding:0.9rem 2.5rem;border-radius:12px;font-size:0.95rem;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;gap:0.5rem;transition:all 0.3s;border:none;cursor:pointer;}
.btn-download-lg:hover{box-shadow:0 8px 24px rgba(99,102,241,0.4);transform:translateY(-2px);color:#fff;}
.btn-fav-lg{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.25);color:#f87171;padding:0.9rem 1.8rem;border-radius:12px;font-size:0.95rem;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:0.5rem;cursor:pointer;transition:all 0.2s;}
.btn-fav-lg:hover,.btn-fav-lg.active{background:rgba(239,68,68,0.25);}

.related-section{max-width:1100px;margin:3rem auto;padding:0 2rem 3rem;}
.related-section h3{font-family:'Sora',sans-serif;font-size:1.3rem;font-weight:700;color:#f1f5f9;margin-bottom:1.5rem;}
.related-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:1.2rem;}
.rel-card{background:#1e293b;border:1px solid rgba(255,255,255,0.07);border-radius:12px;overflow:hidden;text-decoration:none;transition:all 0.3s;}
.rel-card:hover{transform:translateY(-3px);border-color:rgba(99,102,241,0.3);}
.rel-img{aspect-ratio:3/4;background:#2d3748;display:flex;align-items:center;justify-content:center;}
.rel-img i{font-size:2rem;color:#475569;}
.rel-info{padding:1rem;}
.rel-title{font-size:0.88rem;font-weight:700;color:#f1f5f9;margin-bottom:0.2rem;}
.rel-cat{font-size:0.72rem;color:#6366f1;}
.site-footer{background:#0f172a;border-top:1px solid rgba(255,255,255,0.06);padding:2rem 0;text-align:center;color:#475569;font-size:0.82rem;}
@media(max-width:768px){.detail-wrap{grid-template-columns:1fr;}}
</style>
</head>
<body>
<div id="toaster-container"></div>
<nav class="nav-top">
<div class="nav-inner">
    <a href="<?= SITE_URL ?>" class="brand"><div class="brand-box"><i class="fas fa-file-alt" style="color:#fff;font-size:0.85rem"></i></div><span class="brand-txt">CV <span>Craft</span></span></a>
    <div class="nav-links d-none d-md-flex"><a href="<?= SITE_URL ?>">Home</a><a href="<?= SITE_URL ?>/templates_browse.php">Templates</a><a href="<?= SITE_URL ?>/about.php">About</a><a href="<?= SITE_URL ?>/contact.php">Contact</a></div>
    <div class="nav-btns">
        <?php if(isset($_SESSION['candidate_id'])): ?>
        <a href="<?= CANDIDATE_URL ?>/dashboard.php" class="btn-nav-outline"><i class="fas fa-user me-1"></i>Dashboard</a>
        <?php else: ?>
        <a href="<?= SITE_URL ?>/login.php" class="btn-nav-outline">Log In</a>
        <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-nav-primary">Sign Up</a>
        <?php endif; ?>
    </div>
</div>
</nav>

<div class="detail-wrap">
    <div class="preview-col">
        <?php if($tpl['preview_image'] && file_exists(__DIR__.'/uploads/'.$tpl['preview_image'])): ?>
        <img src="<?= SITE_URL ?>/uploads/<?= $tpl['preview_image'] ?>" alt="<?= htmlspecialchars($tpl['title']) ?>">
        <?php else: ?>
        <div class="mock-preview-lg">
            <div class="bar title"></div><div class="bar mid"></div><div class="bar short"></div>
            <div class="section"></div><div class="bar"></div><div class="bar mid"></div><div class="bar short"></div>
            <div class="section"></div><div class="bar mid"></div><div class="bar"></div>
        </div>
        <?php endif; ?>
    </div>
    <div class="info-col">
        <div class="breadcrumb-bar"><a href="templates_browse.php">Templates</a> <i class="fas fa-chevron-right" style="font-size:0.6rem"></i> <a href="templates_browse.php?category=<?= $tpl['category_slug'] ?>"><?= htmlspecialchars($tpl['category_name']) ?></a> <i class="fas fa-chevron-right" style="font-size:0.6rem"></i> <span style="color:#94a3b8"><?= htmlspecialchars($tpl['title']) ?></span></div>
        <h1 class="tpl-title"><?= htmlspecialchars($tpl['title']) ?></h1>
        <span class="tpl-cat-badge"><i class="fas <?= $tpl['category_icon'] ?>"></i> <?= htmlspecialchars($tpl['category_name']) ?></span>
        <div class="tpl-stats">
            <span class="tpl-stat"><i class="fas fa-download"></i> <?= number_format($tpl['download_count']) ?> downloads</span>
            <span class="tpl-stat"><i class="fas fa-file"></i> <?= strtoupper($tpl['file_type']) ?></span>
            <span class="tpl-stat"><i class="fas fa-calendar"></i> <?= formatDate($tpl['created_at']) ?></span>
        </div>
        <p class="tpl-description"><?= nl2br(htmlspecialchars($tpl['description'])) ?></p>
        <?php if(!empty($tags)): ?>
        <div class="tpl-tags">
            <?php foreach($tags as $tag): ?><span class="tag"><?= htmlspecialchars(trim($tag)) ?></span><?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="action-btns">
            <?php if(isset($_SESSION['candidate_id'])): ?>
            <a href="download.php?id=<?= $tpl['id'] ?>" class="btn-download-lg"><i class="fas fa-download"></i> Download Now</a>
            <button class="btn-fav-lg <?= $isFav?'active':'' ?>" onclick="toggleFav(<?= $tpl['id'] ?>,this)"><i class="<?= $isFav?'fas':'far' ?> fa-heart"></i> <?= $isFav?'Saved':'Save' ?></button>
            <?php else: ?>
            <a href="login.php" class="btn-download-lg"><i class="fas fa-lock"></i> Login to Download</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if(!empty($related)): ?>
<div class="related-section">
    <h3><i class="fas fa-layer-group me-2" style="color:#6366f1"></i>Related Templates</h3>
    <div class="related-grid">
        <?php foreach($related as $r): ?>
        <a href="template_detail.php?id=<?= $r['id'] ?>" class="rel-card">
            <div class="rel-img"><i class="fas <?= $r['category_icon'] ?>"></i></div>
            <div class="rel-info">
                <div class="rel-title"><?= htmlspecialchars($r['title']) ?></div>
                <div class="rel-cat"><?= htmlspecialchars($r['category_name']) ?></div>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<footer class="site-footer"><p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</p></footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="includes/common.js"></script>
<script>
function toggleFav(tid, btn) {
    fetch('ajax/toggle_favorite.php', {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'template_id='+tid})
    .then(r=>r.json()).then(d=>{
        if(d.success){btn.classList.toggle('active');btn.querySelector('i').className=d.is_fav?'fas fa-heart':'far fa-heart';showToast(d.message,'success');}
        else showToast(d.message||'Error','danger');
    });
}
</script>
<?php include 'includes/toaster.php'; ?>
</body>
</html>
