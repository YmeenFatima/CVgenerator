# CV Marker Pro v4.0 - Implementation Guide
## Based on CV Wizard Screenshot Analysis

---

## 📋 Overview

Aapke CV Wizard screenshot ke basis par maine CV Marker Pro ko update kiya hai. Yeh guide aapko batayega ke naye features kaise implement karein.

---

## 🎯 Key Features Added

### 1. **Real-Time Form Validation** ✅

Jab user form fields mein data type kare, turant validation ho.

**Screenshot Reference**: Personal details section

```javascript
// HTML mein
<input type="text" 
       name="given_name"
       data-validate="required|min:2"
       placeholder="Enter first name">

<input type="email" 
       name="email"
       data-validate="required|email"
       placeholder="Enter email">

<input type="tel" 
       name="phone"
       data-validate="phone"
       placeholder="Phone number">
```

**Validation Rules Available**:
- `required` - Field zaruri hai
- `email` - Valid email format
- `phone` - 10-15 digits
- `min:5` - Minimum 5 characters
- `max:50` - Maximum 50 characters

---

### 2. **Auto-Save Functionality** 💾

User jab form fill kar rahe hain, automatic save ho jaye har 2 seconds baad.

**Implementation**:

```php
// cv_builder.php mein ye add karein

<?php
// ... existing code ...
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Auto-save logic
    if (isset($_POST['auto_save'])) {
        $db = getDB();
        $stmt = $db->prepare("UPDATE candidates SET 
            first_name = ?,
            last_name = ?,
            email = ?,
            phone = ?
            WHERE id = ?");
        
        $stmt->execute([
            $_POST['first_name'] ?? '',
            $_POST['last_name'] ?? '',
            $_POST['email'] ?? '',
            $_POST['phone'] ?? '',
            $_SESSION['candidate_id']
        ]);
        
        echo json_encode(['success' => true, 'message' => 'CV saved']);
        exit;
    }
}
?>
```

**JavaScript**:

```javascript
// HTML mein form
<form id="cvForm" method="POST">
    <!-- form fields -->
    <input type="hidden" name="auto_save" value="1">
</form>

<script>
initCVAutoSave('#cvForm');
</script>
```

---

### 3. **Live Preview Sync** 👀

Jab user form mein type kare, right side preview immediately update ho.

**HTML Setup**:

```html
<!-- LEFT PANEL - Form -->
<div class="form-panel">
    <input type="text" 
           data-preview-target="fullName"
           data-preview-trigger
           name="full_name"
           placeholder="Full Name">
    
    <input type="text" 
           data-preview-target="jobTitle"
           data-preview-trigger
           name="desired_job"
           placeholder="Desired Job Position">
    
    <input type="email" 
           data-preview-target="email"
           data-preview-trigger
           name="email"
           placeholder="Email Address">
    
    <input type="tel" 
           data-preview-target="phone"
           data-preview-trigger
           name="phone"
           placeholder="Phone Number">
    
    <input type="text" 
           data-preview-target="address"
           data-preview-trigger
           name="address"
           placeholder="Address">
    
    <input type="text" 
           data-preview-target="city"
           data-preview-trigger
           name="city"
           placeholder="City">
</div>

<!-- RIGHT PANEL - Live Preview -->
<div class="preview-panel">
    <div class="preview-section personal">
        <img data-preview="photo" src="default.jpg" alt="Photo">
        
        <h2>
            <span data-preview="fullName">Your Name</span>
        </h2>
        
        <p data-preview="jobTitle" style="display:none;">
            Job Title will appear here
        </p>
        
        <div class="contact-info">
            <p>📧 <span data-preview="email">email@example.com</span></p>
            <p>📞 <span data-preview="phone">+92 300 1234567</span></p>
            <p>📍 <span data-preview="address">Address</span>, <span data-preview="city">City</span></p>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    initCVPreviewSync();
});
</script>
```

---

### 4. **Toast Notifications** 🔔

Success/Error messages ke liye better UI.

**Usage Examples**:

```javascript
// Success - Green
showToast('✓ CV saved successfully!', 'success', 4000);

// Error - Red
showToast('✗ Failed to save CV', 'error', 4000);

// Info - Blue
showToast('ℹ Processing your CV...', 'info', 3000);

// Warning - Yellow
showToast('⚠ Some fields are empty', 'warning', 4000);
```

**Where to Use**:

```php
<?php
// cv_builder.php mein

if ($_POST) {
    try {
        // Save to database
        // ...
        
        // Success message
        echo '<script>
            document.addEventListener("DOMContentLoaded", function() {
                showToast("CV updated successfully!", "success");
            });
        </script>';
    } catch (Exception $e) {
        echo '<script>
            document.addEventListener("DOMContentLoaded", function() {
                showToast("Error: ' . $e->getMessage() . '", "error");
            });
        </script>';
    }
}
?>
```

---

### 5. **Better Form Sections Management** 📑

Personal Details, Education, Experience etc. ko smooth tabs se switch karein.

**HTML**:

```html
<div class="builder-main">
    <!-- TAB BUTTONS -->
    <div class="section-tabs">
        <button class="stab active" data-tab="personal">
            👤 Personal
        </button>
        <button class="stab" data-tab="education">
            🎓 Education
        </button>
        <button class="stab" data-tab="experience">
            💼 Experience
        </button>
        <button class="stab" data-tab="skills">
            ⭐ Skills
        </button>
    </div>

    <!-- PERSONAL DETAILS SECTION -->
    <div class="form-section active" id="personal">
        <h3 class="sec-head">Personal Details</h3>
        
        <div class="fg">
            <label class="fl">Given Name</label>
            <input type="text" class="fi" data-validate="required|min:2"
                   data-preview-target="firstName" placeholder="First name">
        </div>
        
        <div class="fg">
            <label class="fl">Family Name</label>
            <input type="text" class="fi" data-validate="required|min:2"
                   data-preview-target="lastName" placeholder="Last name">
        </div>
        
        <div class="fg">
            <label class="fl">Email Address</label>
            <input type="email" class="fi" data-validate="required|email"
                   data-preview-target="email" placeholder="email@example.com">
        </div>
        
        <div class="fg">
            <label class="fl">Phone Number</label>
            <input type="tel" class="fi" data-validate="phone"
                   data-preview-target="phone" placeholder="Phone number">
        </div>
        
        <div class="fg">
            <label class="fl">Address</label>
            <input type="text" class="fi" 
                   data-preview-target="address" placeholder="Street address">
        </div>
        
        <div class="frow">
            <div class="fg">
                <label class="fl">Post Code</label>
                <input type="text" class="fi" 
                       data-preview-target="postcode" placeholder="Post code">
            </div>
            <div class="fg">
                <label class="fl">City</label>
                <input type="text" class="fi" 
                       data-preview-target="city" placeholder="City">
            </div>
        </div>
    </div>

    <!-- EDUCATION SECTION -->
    <div class="form-section" id="education">
        <h3 class="sec-head">Education</h3>
        
        <div id="education-entries">
            <div class="entry-block">
                <div class="entry-block-title">
                    <i class="fas fa-graduation-cap"></i> Education #1
                    <button class="rm-btn" type="button">Remove</button>
                </div>
                
                <div class="fg">
                    <label class="fl">School/University</label>
                    <input type="text" class="fi" 
                           data-validate="required|min:3"
                           placeholder="Institution name">
                </div>
                
                <div class="fg">
                    <label class="fl">Degree/Certification</label>
                    <input type="text" class="fi" 
                           placeholder="e.g., Bachelor of Science">
                </div>
                
                <div class="frow">
                    <div class="fg">
                        <label class="fl">Field of Study</label>
                        <input type="text" class="fi" 
                               placeholder="e.g., Computer Science">
                    </div>
                    <div class="fg">
                        <label class="fl">Graduation Year</label>
                        <input type="number" class="fi" 
                               placeholder="2024" min="1950" max="2100">
                    </div>
                </div>
            </div>
        </div>
        
        <button class="add-btn" type="button" id="add-education">
            <i class="fas fa-plus"></i> Add Education
        </button>
    </div>

    <!-- EXPERIENCE SECTION -->
    <div class="form-section" id="experience">
        <h3 class="sec-head">Work Experience</h3>
        
        <div id="experience-entries">
            <div class="entry-block">
                <div class="entry-block-title">
                    <i class="fas fa-briefcase"></i> Job #1
                    <button class="rm-btn" type="button">Remove</button>
                </div>
                
                <div class="fg">
                    <label class="fl">Job Title</label>
                    <input type="text" class="fi" 
                           data-validate="required"
                           placeholder="e.g., Software Engineer">
                </div>
                
                <div class="fg">
                    <label class="fl">Company Name</label>
                    <input type="text" class="fi" 
                           data-validate="required"
                           placeholder="Company name">
                </div>
                
                <div class="frow">
                    <div class="fg">
                        <label class="fl">Start Date</label>
                        <input type="month" class="fi">
                    </div>
                    <div class="fg">
                        <label class="fl">End Date</label>
                        <input type="month" class="fi">
                    </div>
                </div>
                
                <div class="fg">
                    <label class="fl">Description</label>
                    <textarea class="fi" 
                              placeholder="Describe your responsibilities..."
                              rows="3"></textarea>
                </div>
            </div>
        </div>
        
        <button class="add-btn" type="button" id="add-experience">
            <i class="fas fa-plus"></i> Add Experience
        </button>
    </div>

    <!-- SKILLS SECTION -->
    <div class="form-section" id="skills">
        <h3 class="sec-head">Skills & Languages</h3>
        
        <div class="fg">
            <label class="fl">Professional Skills</label>
            <div class="skill-wrap" id="skills-input">
                <input type="text" class="ski" placeholder="Add a skill...">
            </div>
            <small style="color: #64748b;">Type skill name aur Enter press karein</small>
        </div>
        
        <div class="fg" style="margin-top: 1.5rem;">
            <label class="fl">Languages</label>
            <div class="skill-wrap" id="languages-input">
                <input type="text" class="ski" placeholder="Add a language...">
            </div>
            <small style="color: #64748b;">Type language name aur Enter press karein</small>
        </div>
    </div>
</div>
```

**JavaScript for Tab Switching**:

```javascript
function initTabSwitching() {
    document.querySelectorAll('.stab').forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active from all tabs
            document.querySelectorAll('.stab').forEach(t => 
                t.classList.remove('active')
            );
            
            // Hide all sections
            document.querySelectorAll('.form-section').forEach(s => 
                s.classList.remove('active')
            );
            
            // Add active to clicked tab
            this.classList.add('active');
            
            // Show corresponding section
            const tabName = this.dataset.tab;
            document.getElementById(tabName).classList.add('active');
        });
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initTabSwitching();
    initCVAutoSave('#cvForm');
    initCVPreviewSync();
});
```

---

### 6. **Skills Tag System** 🏷️

Skills aur Languages ke liye interactive tag system.

**JavaScript**:

```javascript
function initSkillsTags() {
    const skillsInput = document.getElementById('skills-input');
    const languagesInput = document.getElementById('languages-input');
    
    [skillsInput, languagesInput].forEach(wrapper => {
        if (!wrapper) return;
        
        const input = wrapper.querySelector('.ski');
        const isLanguage = wrapper.id === 'languages-input';
        
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const text = this.value.trim();
                
                if (text) {
                    const tag = document.createElement('span');
                    tag.className = `stag ${isLanguage ? 'lang' : ''}`;
                    tag.innerHTML = `
                        ${text}
                        <button type="button" onclick="this.parentElement.remove()">
                            ×
                        </button>
                    `;
                    
                    // Insert before input
                    input.parentElement.insertBefore(tag, input);
                    this.value = '';
                    
                    showToast(`"${text}" added!`, 'success', 2000);
                }
            }
        });
    });
}

// Call in DOMContentLoaded
document.addEventListener('DOMContentLoaded', function() {
    initSkillsTags();
});
```

---

### 7. **Template Switching** 🎨

User mein kaunsa template use karna hai ye select kar sakte hain.

```html
<div class="tpl-switcher">
    <button class="tpl-btn active" data-template="1">Modern</button>
    <button class="tpl-btn" data-template="2">Minimal</button>
    <button class="tpl-btn" data-template="3">Glass</button>
    <button class="tpl-btn" data-template="4">Executive</button>
    <button class="tpl-btn" data-template="5">Startup</button>
</div>

<script>
function initTemplateSwitch() {
    document.querySelectorAll('[data-template]').forEach(btn => {
        btn.addEventListener('click', function() {
            const templateId = this.dataset.template;
            
            // Remove active
            document.querySelectorAll('[data-template]').forEach(b => 
                b.classList.remove('active')
            );
            
            // Add active
            this.classList.add('active');
            
            // Load template
            loadTemplate(templateId);
            showToast(`Template ${templateId} loaded!`, 'success');
        });
    });
}

function loadTemplate(templateId) {
    const preview = document.getElementById('cvPreview');
    if (!preview) return;
    
    const templateFiles = {
        1: 'template1_modern.html',
        2: 'template2_minimal.html',
        3: 'template3_glassmorphism.html',
        4: 'template4_executive.html',
        5: 'template5_startup.html'
    };
    
    fetch(`/templates/${templateFiles[templateId]}`)
        .then(r => r.text())
        .then(html => {
            preview.innerHTML = html;
            syncPreviewData();
        })
        .catch(err => showToast('Error loading template', 'error'));
}

document.addEventListener('DOMContentLoaded', function() {
    initTemplateSwitch();
});
</script>
```

---

### 8. **Download CV as PDF** 📥

```html
<button class="btn-download-cv" id="downloadBtn">
    <i class="fas fa-download"></i> Download CV
</button>

<script>
function initDownloadPDF() {
    const btn = document.getElementById('downloadBtn');
    if (!btn) return;
    
    btn.addEventListener('click', function() {
        const element = document.getElementById('cvPreview');
        if (!element) {
            showToast('Preview not found', 'error');
            return;
        }
        
        showLoader();
        
        const options = {
            margin: 5,
            filename: 'cv-sana-fayaz.pdf',
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2 },
            jsPDF: { orientation: 'portrait', unit: 'mm', format: 'a4' }
        };
        
        html2pdf()
            .set(options)
            .from(element)
            .save()
            .finally(() => {
                hideLoader();
                showToast('CV downloaded!', 'success');
            });
    });
}

document.addEventListener('DOMContentLoaded', function() {
    initDownloadPDF();
});
</script>
```

---

## 🚀 Quick Start Implementation

### Step 1: Add Updated Files

```bash
# Copy updated files
cp includes/common.js cv_marker_final/includes/
cp includes/common.css cv_marker_final/includes/
```

### Step 2: Update cv_builder.php

Add these lines in the `<head>`:

```php
<script src="<?= SITE_URL ?>/includes/common.js"></script>
<link href="<?= SITE_URL ?>/includes/common.css" rel="stylesheet">
```

### Step 3: Add Form Validation

Update all form inputs with `data-validate` attributes.

### Step 4: Initialize Features

```html
<script>
document.addEventListener('DOMContentLoaded', function() {
    initPasswordToggle();
    initDarkMode();
    initFormValidation();
    initSidebar();
    initSmoothScroll();
    initTableSearch();
    initCVPreviewSync();
    initCVAutoSave('#cvForm');
    initTabSwitching();
    initSkillsTags();
    initTemplateSwitch();
    initDownloadPDF();
});
</script>
```

---

## 📊 File Changes Summary

```
cv_marker_final/
├── includes/
│   ├── common.js      ← UPDATED (Enhanced with new features)
│   └── common.css     ← UPDATED (Better styling)
├── candidate/
│   └── cv_builder.php ← UPDATE REQUIRED (Add new form elements)
├── templates/
│   ├── template1_modern.html      (No changes needed)
│   ├── template2_minimal.html     (No changes needed)
│   ├── template3_glassmorphism.html
│   ├── template4_executive.html
│   └── template5_startup.html
├── CHANGELOG_V4.md    ← NEW (Detailed changelog)
└── README.md          (No changes needed)
```

---

## ✅ Testing Checklist

- [ ] Form validation working on all fields
- [ ] Auto-save saving data every 2 seconds
- [ ] Live preview updating as user types
- [ ] Toast notifications appearing correctly
- [ ] Tab switching working smoothly
- [ ] Skills tags adding/removing properly
- [ ] Template switching changing preview
- [ ] PDF download working
- [ ] Dark mode toggle working
- [ ] Mobile responsive layout working
- [ ] All error messages displaying correctly

---

## 🎯 Performance Tips

1. **Debounce Auto-Save**: Already implemented (2 second delay)
2. **Lazy Load Templates**: Load only when needed
3. **Cache Form Data**: Use localStorage for backup
4. **Optimize Images**: Compress photo before upload

---

## 📞 Support

If any feature doesn't work:
1. Check browser console for errors
2. Verify all script tags are included
3. Check file paths are correct
4. Test in different browsers

---

**Happy Coding! 🎉**
