<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireCandidate();
$db = getDB();
$cRow = $db->prepare("SELECT * FROM candidates WHERE id=?");
$cRow->execute([$_SESSION['candidate_id']]);
$cand = $cRow->fetch();
$candName = trim(($cand['first_name'] ?? '') . ' ' . ($cand['last_name'] ?? ''));
if (empty($candName)) $candName = $cand['full_name'] ?? 'Candidate';
$savedCv = null;
$savedCvData = null;
$savedCvId = (int)($_GET['id'] ?? 0);
if ($savedCvId > 0) {
    $savedStmt = $db->prepare("SELECT * FROM cvs WHERE id=? AND candidate_id=?");
    $savedStmt->execute([$savedCvId, $_SESSION['candidate_id']]);
    $savedCv = $savedStmt->fetch();
    if ($savedCv) {
        $savedCvData = json_decode($savedCv['data_json'], true);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CV Builder — CV Craft</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Sora:wght@600;700;800&family=Playfair+Display:wght@400;700&family=Roboto:wght@300;400;500;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="<?= SITE_URL ?>/includes/common.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#0f172a;color:#e2e8f0;height:100vh;overflow:hidden;display:flex;flex-direction:column;}

/* Top Nav */
.top-nav{background:#1e293b;border-bottom:1px solid rgba(255,255,255,0.08);padding:0 1.5rem;height:56px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;z-index:100;}
.top-nav-left{display:flex;align-items:center;gap:1rem;}
.top-back{display:flex;align-items:center;gap:0.5rem;color:#94a3b8;text-decoration:none;font-size:0.85rem;transition:color 0.2s;}
.top-back:hover{color:#e2e8f0;}
.top-title{font-family:'Sora',sans-serif;font-weight:700;font-size:0.95rem;color:#f1f5f9;}
.top-nav-right{display:flex;align-items:center;gap:0.8rem;}

/* Template Switcher */
.tpl-switcher{display:flex;gap:0.3rem;flex-wrap:wrap;}
.tpl-btn{padding:0.3rem 0.7rem;border-radius:6px;font-size:0.75rem;font-weight:600;border:1px solid rgba(255,255,255,0.1);background:transparent;color:#94a3b8;cursor:pointer;transition:all 0.2s;}
.tpl-btn:hover{background:rgba(255,255,255,0.06);color:#e2e8f0;}
.tpl-btn.active{background:#6366f1;border-color:#6366f1;color:#fff;}

/* Download Button */
.btn-download-cv{padding:0.4rem 1.2rem;background:#10b981;color:#fff;border:none;border-radius:8px;font-size:0.83rem;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:0.4rem;transition:all 0.2s;}
.btn-download-cv:hover{background:#059669;transform:translateY(-1px);}

/* Main Layout */
.builder-main{display:flex;flex:1;overflow:hidden;}

/* Left Form Panel */
.form-panel{width:480px;flex-shrink:0;background:#1e293b;border-right:1px solid rgba(255,255,255,0.07);overflow-y:auto;display:flex;flex-direction:column;}
.section-tabs{display:flex;overflow-x:auto;padding:0.5rem 1rem 0;gap:0.2rem;border-bottom:1px solid rgba(255,255,255,0.07);flex-shrink:0;}
.stab{padding:0.5rem 0.9rem;border-radius:6px 6px 0 0;font-size:0.78rem;font-weight:600;color:#64748b;cursor:pointer;transition:all 0.2s;white-space:nowrap;border:none;background:none;}
.stab:hover{color:#94a3b8;background:rgba(255,255,255,0.04);}
.stab.active{color:#6366f1;background:rgba(99,102,241,0.12);border-bottom:2px solid #6366f1;}
.form-area{padding:1.5rem;flex:1;}
.form-section{display:none;}
.form-section.active{display:block;}

/* Form Elements */
.fl{font-size:0.78rem;color:#94a3b8;font-weight:500;margin-bottom:0.3rem;display:block;}
.fi{width:100%;padding:0.6rem 0.85rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;color:#e2e8f0;font-size:0.87rem;font-family:'Inter',sans-serif;transition:border-color 0.2s;outline:none;}
.fi:focus{border-color:#6366f1;background:rgba(99,102,241,0.04);}
.fi::placeholder{color:#3f566b;}
select.fi option{background:#1e293b;}
textarea.fi{resize:vertical;min-height:70px;}
.fg{margin-bottom:0.9rem;}
.frow{display:grid;grid-template-columns:1fr 1fr;gap:0.8rem;}

/* Entry Blocks */
.entry-block{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:1rem;margin-bottom:0.8rem;position:relative;}
.entry-block-title{font-size:0.78rem;font-weight:600;color:#64748b;margin-bottom:0.8rem;display:flex;align-items:center;gap:0.4rem;}
.rm-btn{position:absolute;top:0.6rem;right:0.6rem;background:rgba(239,68,68,0.12);border:none;color:#f87171;border-radius:5px;padding:0.2rem 0.45rem;font-size:0.72rem;cursor:pointer;}
.rm-btn:hover{background:rgba(239,68,68,0.25);}
.add-btn{width:100%;padding:0.55rem;background:rgba(99,102,241,0.08);border:1px dashed rgba(99,102,241,0.35);border-radius:8px;color:#818cf8;font-size:0.8rem;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:0.4rem;transition:all 0.2s;}
.add-btn:hover{background:rgba(99,102,241,0.15);}

/* Skills Tags */
.skill-wrap{display:flex;flex-wrap:wrap;gap:0.35rem;padding:0.5rem 0.75rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;min-height:42px;cursor:text;}
.stag{background:rgba(99,102,241,0.18);border:1px solid rgba(99,102,241,0.35);color:#a5b4fc;padding:0.18rem 0.5rem;border-radius:15px;font-size:0.75rem;display:flex;align-items:center;gap:0.25rem;}
.stag button{background:none;border:none;color:#a5b4fc;cursor:pointer;font-size:0.8rem;line-height:1;padding:0;}
.stag.lang{background:rgba(16,185,129,0.15);border-color:rgba(16,185,129,0.3);color:#6ee7b7;}
.stag.lang button{color:#6ee7b7;}
.ski{background:none;border:none;outline:none;color:#e2e8f0;font-size:0.85rem;min-width:70px;flex:1;padding:0;}

/* Photo */
.photo-upload{width:90px;height:100px;border:2px dashed rgba(255,255,255,0.15);border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;transition:all 0.2s;background:rgba(255,255,255,0.03);}
.photo-upload:hover{border-color:#6366f1;background:rgba(99,102,241,0.05);}
.photo-upload i{font-size:1.5rem;color:#475569;margin-bottom:0.3rem;}
.photo-upload span{font-size:0.65rem;color:#475569;text-align:center;}
.photo-preview{width:90px;height:100px;border-radius:10px;object-fit:cover;border:2px solid rgba(99,102,241,0.3);}
.sec-head{font-family:'Sora',sans-serif;font-size:0.95rem;font-weight:700;margin-bottom:1rem;display:flex;align-items:center;gap:0.5rem;color:#f1f5f9;}

/* Design Options Panel */
.design-option{margin-bottom:1rem;}
.design-option label{font-size:0.78rem;color:#94a3b8;font-weight:500;margin-bottom:0.4rem;display:block;}
.color-grid{display:flex;flex-wrap:wrap;gap:0.4rem;}
.color-swatch{width:28px;height:28px;border-radius:6px;cursor:pointer;border:2px solid transparent;transition:all 0.2s;}
.color-swatch:hover{transform:scale(1.15);}
.color-swatch.active{border-color:#fff;box-shadow:0 0 0 2px #6366f1;}
.font-btn{padding:0.35rem 0.8rem;border-radius:6px;font-size:0.78rem;font-weight:500;border:1px solid rgba(255,255,255,0.1);background:transparent;color:#94a3b8;cursor:pointer;transition:all 0.2s;}
.font-btn:hover{background:rgba(255,255,255,0.06);color:#e2e8f0;}
.font-btn.active{background:#6366f1;border-color:#6366f1;color:#fff;}

/* Right Preview Panel */
.preview-panel{flex:1;background:#475569;overflow:hidden;display:flex;flex-direction:column;position:relative;}
.preview-toolbar{padding:0.6rem 1rem;background:rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:space-between;flex-shrink:0;}
.preview-toolbar span{font-size:0.78rem;color:#94a3b8;}
.preview-zoom{display:flex;align-items:center;gap:0.4rem;}
.zoom-btn{background:rgba(255,255,255,0.1);border:none;color:#e2e8f0;width:26px;height:26px;border-radius:5px;cursor:pointer;font-size:0.8rem;display:flex;align-items:center;justify-content:center;}
.zoom-btn:hover{background:rgba(255,255,255,0.2);}
.preview-canvas{flex:1;overflow:auto;display:flex;justify-content:center;padding:1.5rem;}
.cv-page{background:#fff;width:595px;min-height:841px;box-shadow:0 8px 32px rgba(0,0,0,0.4);transform-origin:top center;transition:transform 0.3s;}

@media(max-width:900px){
    .form-panel{width:100%;position:absolute;left:0;top:56px;bottom:0;z-index:50;transform:translateX(-100%);transition:transform 0.3s;}
    .form-panel.open{transform:translateX(0);}
}
</style>
</head>
<body>
<div id="toaster-container"></div>

<!-- Top Navigation -->
<div class="top-nav">
  <div class="top-nav-left">
    <a href="dashboard.php" class="top-back"><i class="fas fa-chevron-left"></i> CVs</a>
    <span style="color:rgba(255,255,255,0.15)">|</span>
    <span class="top-title">CV of <?= htmlspecialchars($candName) ?></span>
  </div>
  <div class="top-nav-right">
    <!-- CV Score -->
    <div style="display:flex;align-items:center;gap:0.6rem;margin-right:0.4rem">
      <span style="font-size:0.72rem;color:#64748b;white-space:nowrap">Score</span>
      <div style="width:80px;height:6px;background:rgba(255,255,255,0.08);border-radius:3px;overflow:hidden">
        <div id="cvProgressBar" style="height:100%;width:0%;background:linear-gradient(90deg,#6366f1,#10b981);border-radius:3px;transition:width 0.5s"></div>
      </div>
      <span id="cvProgressPct" style="font-size:0.72rem;font-weight:700;color:#10b981;min-width:28px">0%</span>
    </div>
    <!-- Template Switcher -->
    <div class="tpl-switcher" id="tplSwitcher">
      <button class="tpl-btn active" data-tpl="clean" onclick="switchTpl(this)">Clean</button>
      <button class="tpl-btn" data-tpl="professional" onclick="switchTpl(this)">Professional</button>
      <button class="tpl-btn" data-tpl="modern" onclick="switchTpl(this)">Modern</button>
      <button class="tpl-btn" data-tpl="elegant" onclick="switchTpl(this)">Elegant</button>
      <button class="tpl-btn" data-tpl="creative" onclick="switchTpl(this)">Creative</button>
    </div>
    <button class="btn-download-cv" style="background:#6366f1" onclick="saveCV()"><i class="fas fa-save"></i> Save CV</button>
    <a class="btn-download-cv" style="background:#475569;text-decoration:none" href="cvs.php"><i class="fas fa-folder"></i> My CVs</a>
    <button class="btn-download-cv" onclick="downloadCV()"><i class="fas fa-download"></i> Download PDF</button>
  </div>
</div>

<div class="builder-main">

<!-- LEFT: Form Panel -->
<div class="form-panel">
  <div class="section-tabs">
    <button class="stab active" data-sec="personal" onclick="switchSec(this)"><i class="fas fa-user"></i> Personal</button>
    <button class="stab" data-sec="education" onclick="switchSec(this)"><i class="fas fa-graduation-cap"></i> Education</button>
    <button class="stab" data-sec="experience" onclick="switchSec(this)"><i class="fas fa-briefcase"></i> Experience</button>
    <button class="stab" data-sec="skills" onclick="switchSec(this)"><i class="fas fa-code"></i> Skills</button>
    <button class="stab" data-sec="projects" onclick="switchSec(this)"><i class="fas fa-folder"></i> Projects</button>
    <button class="stab" data-sec="design" onclick="switchSec(this)"><i class="fas fa-palette"></i> Design</button>
  </div>

  <div class="form-area">

    <!-- Personal Details -->
    <div class="form-section active" id="sec-personal">
      <div class="sec-head"><i class="fas fa-user" style="color:#6366f1"></i> Personal Details</div>
      <div style="display:flex;gap:1rem;margin-bottom:1rem">
        <div id="photoBox">
          <label class="photo-upload">
            <input type="file" accept="image/*" hidden onchange="previewPhoto(this)">
            <i class="fas fa-camera-retro"></i>
            <span>Add Photo</span>
          </label>
        </div>
        <div style="flex:1">
          <div class="frow">
            <div class="fg"><label class="fl">First Name</label><input type="text" class="fi" id="fname" value="<?= htmlspecialchars($cand['first_name'] ?? '') ?>" oninput="rp()"></div>
            <div class="fg"><label class="fl">Last Name</label><input type="text" class="fi" id="lname" value="<?= htmlspecialchars($cand['last_name'] ?? '') ?>" oninput="rp()"></div>
          </div>
        </div>
      </div>
      <div class="fg"><label class="fl">Job Title / Headline</label><input type="text" class="fi" id="headline" placeholder="e.g. Senior Software Engineer" oninput="rp()"></div>
      <div class="fg"><label class="fl">Professional Summary</label><textarea class="fi" id="summary" rows="3" placeholder="Brief overview of your experience and goals..." oninput="rp()"></textarea></div>
      <div class="frow">
        <div class="fg"><label class="fl">Email</label><input type="email" class="fi" id="email" value="<?= htmlspecialchars($cand['email'] ?? '') ?>" oninput="rp()"></div>
        <div class="fg"><label class="fl">Phone</label><input type="text" class="fi" id="phone" value="<?= htmlspecialchars($cand['phone'] ?? '') ?>" oninput="rp()"></div>
      </div>
      <div class="fg"><label class="fl">Address</label><input type="text" class="fi" id="address" placeholder="City, Country" oninput="rp()"></div>
      <div class="frow">
        <div class="fg"><label class="fl">LinkedIn URL</label><input type="url" class="fi" id="linkedin" placeholder="https://linkedin.com/in/..." oninput="rp()"></div>
        <div class="fg"><label class="fl">Portfolio / Website</label><input type="url" class="fi" id="portfolio" placeholder="https://..." oninput="rp()"></div>
      </div>
    </div>

    <!-- Education -->
    <div class="form-section" id="sec-education">
      <div class="sec-head"><i class="fas fa-graduation-cap" style="color:#10b981"></i> Education</div>
      <div id="eduList"></div>
      <button class="add-btn" onclick="addEdu()"><i class="fas fa-plus"></i> Add Education</button>
    </div>

    <!-- Experience -->
    <div class="form-section" id="sec-experience">
      <div class="sec-head"><i class="fas fa-briefcase" style="color:#f59e0b"></i> Work Experience</div>
      <div id="expList"></div>
      <button class="add-btn" onclick="addExp()"><i class="fas fa-plus"></i> Add Experience</button>
    </div>

    <!-- Skills -->
    <div class="form-section" id="sec-skills">
      <div class="sec-head"><i class="fas fa-code" style="color:#8b5cf6"></i> Skills</div>
      <div class="fg">
        <label class="fl">Technical Skills (press Enter to add)</label>
        <div class="skill-wrap" id="skillsWrap" onclick="document.getElementById('skillInput').focus()">
          <input type="text" class="ski" id="skillInput" placeholder="Type a skill..." onkeydown="addSkill(event)">
        </div>
      </div>
      <div class="fg" style="margin-top:1rem">
        <label class="fl">Languages (press Enter to add)</label>
        <div class="skill-wrap" id="langsWrap" onclick="document.getElementById('langInput').focus()">
          <input type="text" class="ski" id="langInput" placeholder="e.g. English, Urdu..." onkeydown="addLang(event)">
        </div>
      </div>
    </div>

    <!-- Projects -->
    <div class="form-section" id="sec-projects">
      <div class="sec-head"><i class="fas fa-folder" style="color:#06b6d4"></i> Projects & Certifications</div>
      <div id="projList"></div>
      <button class="add-btn" onclick="addProj()"><i class="fas fa-plus"></i> Add Project</button>
      <div style="margin-top:1.5rem">
        <div class="sec-head"><i class="fas fa-certificate" style="color:#f59e0b"></i> Certifications</div>
        <div id="certList"></div>
        <button class="add-btn" onclick="addCert()"><i class="fas fa-plus"></i> Add Certification</button>
      </div>
    </div>

    <!-- Design Options -->
    <div class="form-section" id="sec-design">
      <div class="sec-head"><i class="fas fa-palette" style="color:#ec4899"></i> Design Options</div>
      
      <div class="design-option">
        <label>Accent Color</label>
        <div class="color-grid" id="colorPicker">
          <div class="color-swatch active" style="background:#1e3a5f" data-color="#1e3a5f" onclick="setColor(this)"></div>
          <div class="color-swatch" style="background:#6366f1" data-color="#6366f1" onclick="setColor(this)"></div>
          <div class="color-swatch" style="background:#10b981" data-color="#10b981" onclick="setColor(this)"></div>
          <div class="color-swatch" style="background:#ef4444" data-color="#ef4444" onclick="setColor(this)"></div>
          <div class="color-swatch" style="background:#f59e0b" data-color="#f59e0b" onclick="setColor(this)"></div>
          <div class="color-swatch" style="background:#8b5cf6" data-color="#8b5cf6" onclick="setColor(this)"></div>
          <div class="color-swatch" style="background:#ec4899" data-color="#ec4899" onclick="setColor(this)"></div>
          <div class="color-swatch" style="background:#06b6d4" data-color="#06b6d4" onclick="setColor(this)"></div>
          <div class="color-swatch" style="background:#000000" data-color="#000000" onclick="setColor(this)"></div>
          <div class="color-swatch" style="background:#374151" data-color="#374151" onclick="setColor(this)"></div>
        </div>
      </div>

      <div class="design-option">
        <label>Heading Color</label>
        <div class="color-grid" id="headingColorPicker">
          <div class="color-swatch active" style="background:#1a1a2e" data-color="#1a1a2e" onclick="setHeadingColor(this)"></div>
          <div class="color-swatch" style="background:#1e3a5f" data-color="#1e3a5f" onclick="setHeadingColor(this)"></div>
          <div class="color-swatch" style="background:#000000" data-color="#000000" onclick="setHeadingColor(this)"></div>
          <div class="color-swatch" style="background:#333333" data-color="#333333" onclick="setHeadingColor(this)"></div>
          <div class="color-swatch" style="background:#6366f1" data-color="#6366f1" onclick="setHeadingColor(this)"></div>
          <div class="color-swatch" style="background:#059669" data-color="#059669" onclick="setHeadingColor(this)"></div>
        </div>
      </div>

      <div class="design-option">
        <label>Body Text Color</label>
        <div class="color-grid" id="textColorPicker">
          <div class="color-swatch active" style="background:#333333" data-color="#333333" onclick="setTextColor(this)"></div>
          <div class="color-swatch" style="background:#000000" data-color="#000000" onclick="setTextColor(this)"></div>
          <div class="color-swatch" style="background:#1e293b" data-color="#1e293b" onclick="setTextColor(this)"></div>
          <div class="color-swatch" style="background:#475569" data-color="#475569" onclick="setTextColor(this)"></div>
          <div class="color-swatch" style="background:#555555" data-color="#555555" onclick="setTextColor(this)"></div>
        </div>
      </div>

      <div class="design-option">
        <label>Font Family</label>
        <div style="display:flex;flex-wrap:wrap;gap:0.4rem">
          <button class="font-btn active" data-font="'Inter',sans-serif" onclick="setFont(this)">Inter</button>
          <button class="font-btn" data-font="'Roboto',sans-serif" onclick="setFont(this)">Roboto</button>
          <button class="font-btn" data-font="'Montserrat',sans-serif" onclick="setFont(this)">Montserrat</button>
          <button class="font-btn" data-font="Arial,sans-serif" onclick="setFont(this)">Arial</button>
          <button class="font-btn" data-font="'Georgia',serif" onclick="setFont(this)">Georgia</button>
          <button class="font-btn" data-font="Calibri,sans-serif" onclick="setFont(this)">Calibri</button>
        </div>
      </div>

      <div class="design-option">
        <label>Font Size</label>
        <div style="display:flex;align-items:center;gap:0.8rem">
          <input type="range" min="8" max="14" value="10" id="fontSizeSlider" oninput="setFontSize(this.value)" style="flex:1;accent-color:#6366f1">
          <span id="fontSizeLabel" style="font-size:0.78rem;color:#94a3b8;min-width:30px">10px</span>
        </div>
      </div>

      <div class="design-option">
        <label>Line Spacing</label>
        <div style="display:flex;align-items:center;gap:0.8rem">
          <input type="range" min="1.2" max="2.0" step="0.1" value="1.5" id="lineSpacingSlider" oninput="setLineSpacing(this.value)" style="flex:1;accent-color:#6366f1">
          <span id="lineSpacingLabel" style="font-size:0.78rem;color:#94a3b8;min-width:30px">1.5</span>
        </div>
      </div>
    </div>

  </div>
</div>

<!-- RIGHT: Preview Panel -->
<div class="preview-panel">
  <div class="preview-toolbar">
    <span id="previewLabel"><i class="fas fa-eye"></i> Live Preview — Clean Template</span>
    <div class="preview-zoom">
      <button class="zoom-btn" onclick="zoom(-0.1)"><i class="fas fa-minus"></i></button>
      <span style="font-size:0.75rem;color:#94a3b8;min-width:40px;text-align:center" id="zoomPct">85%</span>
      <button class="zoom-btn" onclick="zoom(0.1)"><i class="fas fa-plus"></i></button>
    </div>
  </div>
  <div class="preview-canvas">
    <div class="cv-page" id="cvPage"></div>
  </div>
</div>

</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="<?= SITE_URL ?>/includes/common.js"></script>
<script>
// State
var curTpl='clean', skills=[], langs=[], eduCount=0, expCount=0, projCount=0, certCount=0;
var zoomVal=0.85;
var photoData='';
var accentColor='#1e3a5f';
var headingColor='#1a1a2e';
var textColor='#333333';
var fontFamily="'Inter',sans-serif";
var fontSize=10;
var lineSpacing=1.5;
var savedCvId=<?= (int)($savedCv['id'] ?? 0) ?>;
var loadedCv=<?= json_encode($savedCvData ?: null, JSON_UNESCAPED_UNICODE) ?>;
var loadedTemplate=<?= json_encode($savedCv['template'] ?? 'clean') ?>;

// Section Switching
function switchSec(btn){
    document.querySelectorAll('.stab').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.form-section').forEach(s=>s.classList.remove('active'));
    document.getElementById('sec-'+btn.dataset.sec).classList.add('active');
}

// Template Switching
function switchTpl(btn){
    document.querySelectorAll('.tpl-btn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    curTpl=btn.dataset.tpl;
    var labels={clean:'Clean',professional:'Professional',modern:'Modern',elegant:'Elegant',creative:'Creative'};
    document.getElementById('previewLabel').innerHTML='<i class="fas fa-eye"></i> Live Preview — '+(labels[curTpl]||curTpl)+' Template';
    rp();
}

// Design Options
function setColor(el){
    document.querySelectorAll('#colorPicker .color-swatch').forEach(s=>s.classList.remove('active'));
    el.classList.add('active');
    accentColor=el.dataset.color;
    rp();
}
function setHeadingColor(el){
    document.querySelectorAll('#headingColorPicker .color-swatch').forEach(s=>s.classList.remove('active'));
    el.classList.add('active');
    headingColor=el.dataset.color;
    rp();
}
function setTextColor(el){
    document.querySelectorAll('#textColorPicker .color-swatch').forEach(s=>s.classList.remove('active'));
    el.classList.add('active');
    textColor=el.dataset.color;
    rp();
}
function setFont(btn){
    document.querySelectorAll('.font-btn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    fontFamily=btn.dataset.font;
    rp();
}
function setFontSize(val){
    fontSize=parseInt(val);
    document.getElementById('fontSizeLabel').textContent=val+'px';
    rp();
}
function setLineSpacing(val){
    lineSpacing=parseFloat(val);
    document.getElementById('lineSpacingLabel').textContent=val;
    rp();
}

// Photo
function previewPhoto(inp){
    var file=inp.files[0]; if(!file)return;
    var reader=new FileReader();
    reader.onload=function(e){photoData=e.target.result;document.getElementById('photoBox').innerHTML='<img src="'+photoData+'" class="photo-preview">';rp();};
    reader.readAsDataURL(file);
}

// Education
function addEdu(){
    eduCount++;var id='edu'+eduCount;
    document.getElementById('eduList').insertAdjacentHTML('beforeend',
    '<div class="entry-block" id="'+id+'"><button class="rm-btn" onclick="document.getElementById(\''+id+'\').remove();rp()">✕</button>'+
    '<div class="entry-block-title"><i class="fas fa-graduation-cap"></i> Education</div>'+
    '<div class="frow"><div class="fg"><label class="fl">Degree</label><input type="text" class="fi edu-deg" placeholder="BS Computer Science" oninput="rp()"></div>'+
    '<div class="fg"><label class="fl">Institution</label><input type="text" class="fi edu-school" placeholder="University Name" oninput="rp()"></div></div>'+
    '<div class="frow"><div class="fg"><label class="fl">Year</label><input type="text" class="fi edu-year" placeholder="2019 - 2023" oninput="rp()"></div>'+
    '<div class="fg"><label class="fl">CGPA / Grade</label><input type="text" class="fi edu-cgpa" placeholder="3.8 / 4.0" oninput="rp()"></div></div></div>');
    rp();
}

// Experience
function addExp(){
    expCount++;var id='exp'+expCount;
    document.getElementById('expList').insertAdjacentHTML('beforeend',
    '<div class="entry-block" id="'+id+'"><button class="rm-btn" onclick="document.getElementById(\''+id+'\').remove();rp()">✕</button>'+
    '<div class="entry-block-title"><i class="fas fa-briefcase"></i> Experience</div>'+
    '<div class="frow"><div class="fg"><label class="fl">Job Title</label><input type="text" class="fi exp-title" placeholder="Software Engineer" oninput="rp()"></div>'+
    '<div class="fg"><label class="fl">Company</label><input type="text" class="fi exp-company" placeholder="Company Name" oninput="rp()"></div></div>'+
    '<div class="frow"><div class="fg"><label class="fl">Duration</label><input type="text" class="fi exp-dur" placeholder="Jan 2020 - Present" oninput="rp()"></div>'+
    '<div class="fg"><label class="fl">Location</label><input type="text" class="fi exp-loc" placeholder="Lahore, PK" oninput="rp()"></div></div>'+
    '<div class="fg"><label class="fl">Description</label><textarea class="fi exp-desc" rows="2" placeholder="Key responsibilities..." oninput="rp()"></textarea></div></div>');
    rp();
}

// Projects
function addProj(){
    projCount++;var id='proj'+projCount;
    document.getElementById('projList').insertAdjacentHTML('beforeend',
    '<div class="entry-block" id="'+id+'"><button class="rm-btn" onclick="document.getElementById(\''+id+'\').remove();rp()">✕</button>'+
    '<div class="entry-block-title"><i class="fas fa-folder"></i> Project</div>'+
    '<div class="fg"><label class="fl">Project Name</label><input type="text" class="fi proj-name" placeholder="Project Title" oninput="rp()"></div>'+
    '<div class="fg"><label class="fl">Description</label><textarea class="fi proj-desc" rows="2" placeholder="Brief description..." oninput="rp()"></textarea></div></div>');
    rp();
}

// Certifications
function addCert(){
    certCount++;var id='cert'+certCount;
    document.getElementById('certList').insertAdjacentHTML('beforeend',
    '<div class="entry-block" id="'+id+'"><button class="rm-btn" onclick="document.getElementById(\''+id+'\').remove();rp()">✕</button>'+
    '<div class="entry-block-title"><i class="fas fa-certificate"></i> Certification</div>'+
    '<div class="frow"><div class="fg"><label class="fl">Name</label><input type="text" class="fi cert-name" placeholder="AWS Certified" oninput="rp()"></div>'+
    '<div class="fg"><label class="fl">Issuer / Year</label><input type="text" class="fi cert-issuer" placeholder="Amazon · 2023" oninput="rp()"></div></div></div>');
    rp();
}

// Skills
function addSkill(e){
    if(e.key==='Enter'){e.preventDefault();var v=e.target.value.trim();if(v&&!skills.includes(v)){skills.push(v);renderSkills();}e.target.value='';rp();}
}
function removeSkill(i){skills.splice(i,1);renderSkills();rp();}
function renderSkills(){
    var html='';skills.forEach(function(s,i){html+='<span class="stag">'+s+'<button onclick="removeSkill('+i+')">×</button></span>';});
    document.getElementById('skillsWrap').innerHTML=html+'<input type="text" class="ski" id="skillInput" placeholder="Type skill..." onkeydown="addSkill(event)">';
}
function addLang(e){
    if(e.key==='Enter'){e.preventDefault();var v=e.target.value.trim();if(v&&!langs.includes(v)){langs.push(v);renderLangs();}e.target.value='';rp();}
}
function removeLang(i){langs.splice(i,1);renderLangs();rp();}
function renderLangs(){
    var html='';langs.forEach(function(l,i){html+='<span class="stag lang">'+l+'<button onclick="removeLang('+i+')">×</button></span>';});
    document.getElementById('langsWrap').innerHTML=html+'<input type="text" class="ski" id="langInput" placeholder="Language..." onkeydown="addLang(event)">';
}

// Collect Data
function getData(){
    var d={};
    d.fname=$('#fname').val()||'';d.lname=$('#lname').val()||'';
    d.fullName=(d.fname+' '+d.lname).trim();
    d.headline=$('#headline').val()||'';d.summary=$('#summary').val()||'';
    d.email=$('#email').val()||'';d.phone=$('#phone').val()||'';
    d.address=$('#address').val()||'';d.linkedin=$('#linkedin').val()||'';d.portfolio=$('#portfolio').val()||'';
    d.photo=photoData;d.skills=skills;d.langs=langs;
    d.education=[];
    $('#eduList .entry-block').each(function(){
        d.education.push({deg:$(this).find('.edu-deg').val()||'',school:$(this).find('.edu-school').val()||'',year:$(this).find('.edu-year').val()||'',cgpa:$(this).find('.edu-cgpa').val()||''});
    });
    d.experience=[];
    $('#expList .entry-block').each(function(){
        d.experience.push({title:$(this).find('.exp-title').val()||'',company:$(this).find('.exp-company').val()||'',dur:$(this).find('.exp-dur').val()||'',loc:$(this).find('.exp-loc').val()||'',desc:$(this).find('.exp-desc').val()||''});
    });
    d.projects=[];
    $('#projList .entry-block').each(function(){
        d.projects.push({name:$(this).find('.proj-name').val()||'',desc:$(this).find('.proj-desc').val()||''});
    });
    d.certs=[];
    $('#certList .entry-block').each(function(){
        d.certs.push({name:$(this).find('.cert-name').val()||'',issuer:$(this).find('.cert-issuer').val()||''});
    });
    return d;
}

function setVal(id,val){var el=document.getElementById(id);if(el)el.value=val||'';}
function populateList(listId,items,addFn,classes){
    var list=document.getElementById(listId);
    if(!list)return;
    list.innerHTML='';
    (items||[]).forEach(function(item){
        addFn();
        var block=list.lastElementChild;
        if(!block)return;
        Object.keys(classes).forEach(function(k){
            var input=block.querySelector(classes[k]);
            if(input)input.value=item[k]||'';
        });
    });
}
function loadSavedCv(){
    if(!loadedCv)return;
    setVal('fname',loadedCv.fname);setVal('lname',loadedCv.lname);setVal('headline',loadedCv.headline);setVal('summary',loadedCv.summary);
    setVal('email',loadedCv.email);setVal('phone',loadedCv.phone);setVal('address',loadedCv.address);setVal('linkedin',loadedCv.linkedin);setVal('portfolio',loadedCv.portfolio);
    skills=loadedCv.skills||[];langs=loadedCv.langs||[];photoData=loadedCv.photo||'';renderSkills();renderLangs();
    if(photoData)document.getElementById('photoBox').innerHTML='<img src="'+photoData+'" class="photo-preview">';
    populateList('eduList',loadedCv.education,addEdu,{deg:'.edu-deg',school:'.edu-school',year:'.edu-year',cgpa:'.edu-cgpa'});
    populateList('expList',loadedCv.experience,addExp,{title:'.exp-title',company:'.exp-company',dur:'.exp-dur',loc:'.exp-loc',desc:'.exp-desc'});
    populateList('projList',loadedCv.projects,addProj,{name:'.proj-name',desc:'.proj-desc'});
    populateList('certList',loadedCv.certs,addCert,{name:'.cert-name',issuer:'.cert-issuer'});
    var btn=document.querySelector('[data-tpl="'+loadedTemplate+'"]');
    if(btn)switchTpl(btn);
    rp();
}

function saveCV(){
    var d=getData();
    var title=(d.fullName||'Untitled')+' - '+(d.headline||'CV');
    var btns=document.querySelectorAll('.btn-download-cv');
    fetch('save_cv.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:savedCvId,title:title,template:curTpl,data:d})})
    .then(function(r){return r.json();})
    .then(function(res){
        if(res.success){savedCvId=res.id;if(typeof showToast==='function')showToast(res.message,'success');}
        else if(typeof showToast==='function')showToast(res.message||'Unable to save CV','danger');
    }).catch(function(){if(typeof showToast==='function')showToast('Unable to save CV','danger');});
}

// Update CV Progress
function updateProgress(d){
    var filled=0,total=8;
    if(d.fullName)filled++;if(d.headline)filled++;if(d.email)filled++;if(d.phone)filled++;
    if(d.education.length)filled++;if(d.experience.length)filled++;if(d.skills.length)filled++;if(d.summary)filled++;
    var pct=Math.round((filled/total)*100);
    $('#cvProgressBar').css('width',pct+'%');
    $('#cvProgressPct').text(pct+'%');
}

// ========================
// CV TEMPLATE RENDERERS
// ========================

function renderClean(d){
    var h='<div style="font-family:'+fontFamily+';font-size:'+fontSize+'px;line-height:'+lineSpacing+';color:'+textColor+';padding:40px 45px">';
    // Header
    h+='<div style="text-align:center;margin-bottom:20px;border-bottom:2px solid '+accentColor+';padding-bottom:15px">';
    if(d.photo)h+='<img src="'+d.photo+'" style="width:70px;height:70px;border-radius:50%;object-fit:cover;margin-bottom:8px;border:2px solid '+accentColor+'">';
    h+='<div style="font-size:'+(fontSize+10)+'px;font-weight:700;color:'+headingColor+';letter-spacing:1px">'+esc(d.fullName||'Your Name')+'</div>';
    if(d.headline)h+='<div style="font-size:'+(fontSize+2)+'px;color:'+accentColor+';font-weight:500;margin-top:3px">'+esc(d.headline)+'</div>';
    var contact=[];
    if(d.email)contact.push('<span>✉ '+esc(d.email)+'</span>');
    if(d.phone)contact.push('<span>☎ '+esc(d.phone)+'</span>');
    if(d.address)contact.push('<span>📍 '+esc(d.address)+'</span>');
    if(contact.length)h+='<div style="font-size:'+(fontSize-1)+'px;color:#666;margin-top:6px;display:flex;justify-content:center;gap:15px;flex-wrap:wrap">'+contact.join('')+'</div>';
    h+='</div>';
    // Summary
    if(d.summary){h+=secTitle('Professional Summary');h+='<p style="margin:0 0 15px">'+esc(d.summary)+'</p>';}
    // Experience
    if(d.experience.length){h+=secTitle('Work Experience');d.experience.forEach(function(e){h+=entryBlock(e.title,e.company,e.dur,e.loc,e.desc);});}
    // Education
    if(d.education.length){h+=secTitle('Education');d.education.forEach(function(e){h+='<div style="margin-bottom:8px"><div style="font-weight:600;color:'+headingColor+'">'+esc(e.deg)+'</div><div style="color:#666">'+esc(e.school)+(e.year?' · '+esc(e.year):'')+(e.cgpa?' · '+esc(e.cgpa):'')+'</div></div>';});}
    // Skills
    if(d.skills.length){h+=secTitle('Skills');h+='<div style="display:flex;flex-wrap:wrap;gap:5px">'; d.skills.forEach(function(s){h+='<span style="background:'+accentColor+'15;border:1px solid '+accentColor+'30;color:'+accentColor+';padding:2px 10px;border-radius:4px;font-size:'+(fontSize-1)+'px;font-weight:500">'+esc(s)+'</span>';});h+='</div><div style="margin-bottom:15px"></div>';}
    // Projects
    if(d.projects.length){h+=secTitle('Projects');d.projects.forEach(function(p){h+='<div style="margin-bottom:8px"><div style="font-weight:600;color:'+headingColor+'">'+esc(p.name)+'</div>';if(p.desc)h+='<div style="color:#555;font-size:'+(fontSize-1)+'px">'+esc(p.desc)+'</div>';h+='</div>';});}
    // Certifications
    if(d.certs.length){h+=secTitle('Certifications');d.certs.forEach(function(c){h+='<div style="margin-bottom:5px"><span style="font-weight:600;color:'+headingColor+'">'+esc(c.name)+'</span>';if(c.issuer)h+=' — <span style="color:#666">'+esc(c.issuer)+'</span>';h+='</div>';});}
    // Languages
    if(d.langs.length){h+=secTitle('Languages');h+='<div style="display:flex;flex-wrap:wrap;gap:8px">'; d.langs.forEach(function(l){h+='<span style="color:'+textColor+'">'+esc(l)+'</span>';});h+='</div>';}
    h+='</div>';return h;
}

function renderProfessional(d){
    var h='<div style="font-family:'+fontFamily+';font-size:'+fontSize+'px;line-height:'+lineSpacing+';display:flex;min-height:841px">';
    // Sidebar
    h+='<div style="width:200px;background:'+accentColor+';color:#fff;padding:30px 20px;flex-shrink:0">';
    if(d.photo)h+='<img src="'+d.photo+'" style="width:80px;height:80px;border-radius:50%;object-fit:cover;border:3px solid rgba(255,255,255,0.3);display:block;margin:0 auto 12px">';
    else h+='<div style="width:70px;height:70px;border-radius:50%;background:rgba(255,255,255,0.15);margin:0 auto 12px;display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:700">'+esc((d.fname||'?')[0])+'</div>';
    if(d.headline)h+='<div style="text-align:center;font-size:'+(fontSize-1)+'px;opacity:0.85;margin-bottom:18px">'+esc(d.headline)+'</div>';
    // Contact
    h+='<div style="font-size:'+(fontSize-2)+'px;font-weight:700;text-transform:uppercase;letter-spacing:1px;border-bottom:1px solid rgba(255,255,255,0.2);padding-bottom:4px;margin-bottom:8px">Contact</div>';
    if(d.email)h+='<div style="font-size:'+(fontSize-2)+'px;margin-bottom:4px;word-break:break-all">✉ '+esc(d.email)+'</div>';
    if(d.phone)h+='<div style="font-size:'+(fontSize-2)+'px;margin-bottom:4px">☎ '+esc(d.phone)+'</div>';
    if(d.address)h+='<div style="font-size:'+(fontSize-2)+'px;margin-bottom:4px">📍 '+esc(d.address)+'</div>';
    if(d.linkedin)h+='<div style="font-size:'+(fontSize-2)+'px;margin-bottom:4px;word-break:break-all">🔗 LinkedIn</div>';
    // Skills in sidebar
    if(d.skills.length){h+='<div style="font-size:'+(fontSize-2)+'px;font-weight:700;text-transform:uppercase;letter-spacing:1px;border-bottom:1px solid rgba(255,255,255,0.2);padding-bottom:4px;margin:15px 0 8px">Skills</div>';
    d.skills.forEach(function(s){h+='<div style="font-size:'+(fontSize-1)+'px;margin-bottom:4px;display:flex;align-items:center;gap:5px"><span style="width:5px;height:5px;background:#fff;border-radius:50%;flex-shrink:0"></span>'+esc(s)+'</div>';});}
    // Languages in sidebar
    if(d.langs.length){h+='<div style="font-size:'+(fontSize-2)+'px;font-weight:700;text-transform:uppercase;letter-spacing:1px;border-bottom:1px solid rgba(255,255,255,0.2);padding-bottom:4px;margin:15px 0 8px">Languages</div>';
    d.langs.forEach(function(l){h+='<div style="font-size:'+(fontSize-1)+'px;margin-bottom:4px">'+esc(l)+'</div>';});}
    h+='</div>';
    // Main Content
    h+='<div style="flex:1;padding:30px 25px;color:'+textColor+'">';
    h+='<div style="font-size:'+(fontSize+12)+'px;font-weight:700;color:'+headingColor+';letter-spacing:0.5px">'+esc(d.fullName||'Your Name').toUpperCase()+'</div>';
    if(d.headline)h+='<div style="font-size:'+(fontSize+1)+'px;color:'+accentColor+';margin-top:2px;font-weight:500">'+esc(d.headline)+'</div>';
    h+='<div style="height:2px;background:'+accentColor+';margin:12px 0 18px;width:60px"></div>';
    if(d.summary){h+=secTitlePro('Summary');h+='<p style="margin:0 0 15px;color:'+textColor+'">'+esc(d.summary)+'</p>';}
    if(d.experience.length){h+=secTitlePro('Experience');d.experience.forEach(function(e){h+=entryBlock(e.title,e.company,e.dur,e.loc,e.desc);});}
    if(d.education.length){h+=secTitlePro('Education');d.education.forEach(function(e){h+='<div style="margin-bottom:10px"><div style="font-weight:600;color:'+headingColor+'">'+esc(e.deg)+'</div><div style="color:#666;font-size:'+(fontSize-1)+'px">'+esc(e.school)+(e.year?' · '+esc(e.year):'')+(e.cgpa?' · CGPA: '+esc(e.cgpa):'')+'</div></div>';});}
    if(d.projects.length){h+=secTitlePro('Projects');d.projects.forEach(function(p){h+='<div style="margin-bottom:8px"><div style="font-weight:600;color:'+headingColor+'">'+esc(p.name)+'</div>';if(p.desc)h+='<div style="color:#555;font-size:'+(fontSize-1)+'px">'+esc(p.desc)+'</div>';h+='</div>';});}
    if(d.certs.length){h+=secTitlePro('Certifications');d.certs.forEach(function(c){h+='<div style="margin-bottom:5px"><span style="font-weight:600">'+esc(c.name)+'</span>';if(c.issuer)h+=' — <span style="color:#666">'+esc(c.issuer)+'</span>';h+='</div>';});}
    h+='</div></div>';return h;
}

function renderModern(d){
    var h='<div style="font-family:'+fontFamily+';font-size:'+fontSize+'px;line-height:'+lineSpacing+';color:'+textColor+'">';
    // Header with gradient
    h+='<div style="background:linear-gradient(135deg,'+accentColor+','+lighten(accentColor)+');padding:30px 40px;color:#fff">';
    h+='<div style="display:flex;align-items:center;gap:15px">';
    if(d.photo)h+='<img src="'+d.photo+'" style="width:70px;height:70px;border-radius:50%;object-fit:cover;border:3px solid rgba(255,255,255,0.4)">';
    h+='<div><div style="font-size:'+(fontSize+12)+'px;font-weight:700">'+esc(d.fullName||'Your Name')+'</div>';
    if(d.headline)h+='<div style="font-size:'+(fontSize+1)+'px;opacity:0.9;margin-top:2px">'+esc(d.headline)+'</div>';
    h+='</div></div>';
    var contact=[];
    if(d.email)contact.push('✉ '+esc(d.email));if(d.phone)contact.push('☎ '+esc(d.phone));if(d.address)contact.push('📍 '+esc(d.address));
    if(contact.length)h+='<div style="font-size:'+(fontSize-1)+'px;margin-top:10px;opacity:0.85;display:flex;gap:15px;flex-wrap:wrap">'+contact.map(function(c){return'<span>'+c+'</span>';}).join('')+'</div>';
    h+='</div>';
    // Body
    h+='<div style="padding:25px 40px">';
    if(d.summary){h+=secTitleModern('Summary');h+='<p style="margin:0 0 18px">'+esc(d.summary)+'</p>';}
    if(d.experience.length){h+=secTitleModern('Experience');d.experience.forEach(function(e){h+='<div style="margin-bottom:12px;padding-left:12px;border-left:3px solid '+accentColor+'"><div style="font-weight:600;color:'+headingColor+';font-size:'+(fontSize+1)+'px">'+esc(e.title)+'</div><div style="color:'+accentColor+';font-size:'+(fontSize-1)+'px;font-weight:500">'+esc(e.company)+(e.dur?' · '+esc(e.dur):'')+'</div>';if(e.desc)h+='<div style="color:#555;font-size:'+(fontSize-1)+'px;margin-top:4px">'+esc(e.desc)+'</div>';h+='</div>';});}
    if(d.education.length){h+=secTitleModern('Education');d.education.forEach(function(e){h+='<div style="margin-bottom:10px;padding-left:12px;border-left:3px solid '+accentColor+'"><div style="font-weight:600;color:'+headingColor+'">'+esc(e.deg)+'</div><div style="color:#666;font-size:'+(fontSize-1)+'px">'+esc(e.school)+(e.year?' · '+esc(e.year):'')+(e.cgpa?' · '+esc(e.cgpa):'')+'</div></div>';});}
    if(d.skills.length){h+=secTitleModern('Skills');h+='<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:18px">';d.skills.forEach(function(s){h+='<span style="background:'+accentColor+';color:#fff;padding:3px 12px;border-radius:15px;font-size:'+(fontSize-1)+'px;font-weight:500">'+esc(s)+'</span>';});h+='</div>';}
    if(d.projects.length){h+=secTitleModern('Projects');d.projects.forEach(function(p){h+='<div style="margin-bottom:8px"><div style="font-weight:600;color:'+headingColor+'">'+esc(p.name)+'</div>';if(p.desc)h+='<div style="color:#555;font-size:'+(fontSize-1)+'px">'+esc(p.desc)+'</div>';h+='</div>';});}
    if(d.certs.length){h+=secTitleModern('Certifications');d.certs.forEach(function(c){h+='<div style="margin-bottom:5px">✓ <strong>'+esc(c.name)+'</strong>';if(c.issuer)h+=' — '+esc(c.issuer);h+='</div>';});}
    if(d.langs.length){h+=secTitleModern('Languages');h+='<div style="display:flex;gap:12px;flex-wrap:wrap">'; d.langs.forEach(function(l){h+='<span>'+esc(l)+'</span>';});h+='</div>';}
    h+='</div></div>';return h;
}

function renderElegant(d){
    var h='<div style="font-family:Georgia,serif;font-size:'+fontSize+'px;line-height:'+lineSpacing+';color:'+textColor+';padding:45px 50px">';
    // Elegant Header
    h+='<div style="text-align:center;margin-bottom:25px">';
    if(d.photo)h+='<img src="'+d.photo+'" style="width:80px;height:80px;border-radius:50%;object-fit:cover;border:2px solid '+accentColor+';margin-bottom:10px">';
    h+='<div style="font-size:'+(fontSize+14)+'px;font-weight:700;color:'+headingColor+';letter-spacing:3px;text-transform:uppercase">'+esc(d.fullName||'Your Name')+'</div>';
    if(d.headline)h+='<div style="font-size:'+(fontSize+1)+'px;color:'+accentColor+';font-style:italic;margin-top:4px">'+esc(d.headline)+'</div>';
    h+='<div style="width:80px;height:1px;background:'+accentColor+';margin:12px auto"></div>';
    var contact=[];
    if(d.email)contact.push(esc(d.email));if(d.phone)contact.push(esc(d.phone));if(d.address)contact.push(esc(d.address));
    if(contact.length)h+='<div style="font-size:'+(fontSize-1)+'px;color:#888">'+contact.join(' · ')+'</div>';
    h+='</div>';
    // Body with elegant borders
    if(d.summary){h+=secTitleElegant('Profile');h+='<p style="margin:0 0 20px;font-style:italic;color:#555">'+esc(d.summary)+'</p>';}
    if(d.experience.length){h+=secTitleElegant('Experience');d.experience.forEach(function(e){h+='<div style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;align-items:baseline"><div style="font-weight:700;color:'+headingColor+';font-size:'+(fontSize+1)+'px">'+esc(e.title)+'</div><div style="font-size:'+(fontSize-2)+'px;color:#999;font-style:italic">'+esc(e.dur||'')+'</div></div><div style="color:'+accentColor+';font-size:'+(fontSize-1)+'px">'+esc(e.company)+(e.loc?', '+esc(e.loc):'')+'</div>';if(e.desc)h+='<div style="color:#555;font-size:'+(fontSize-1)+'px;margin-top:4px">'+esc(e.desc)+'</div>';h+='</div>';});}
    if(d.education.length){h+=secTitleElegant('Education');d.education.forEach(function(e){h+='<div style="margin-bottom:10px;display:flex;justify-content:space-between"><div><div style="font-weight:700;color:'+headingColor+'">'+esc(e.deg)+'</div><div style="color:#666;font-size:'+(fontSize-1)+'px">'+esc(e.school)+(e.cgpa?' — '+esc(e.cgpa):'')+'</div></div><div style="font-size:'+(fontSize-2)+'px;color:#999;font-style:italic">'+esc(e.year||'')+'</div></div>';});}
    if(d.skills.length){h+=secTitleElegant('Expertise');h+='<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:20px">';d.skills.forEach(function(s){h+='<span style="border:1px solid '+accentColor+';color:'+accentColor+';padding:2px 12px;border-radius:3px;font-size:'+(fontSize-1)+'px">'+esc(s)+'</span>';});h+='</div>';}
    if(d.projects.length){h+=secTitleElegant('Projects');d.projects.forEach(function(p){h+='<div style="margin-bottom:8px"><div style="font-weight:700;color:'+headingColor+'">'+esc(p.name)+'</div>';if(p.desc)h+='<div style="color:#555;font-size:'+(fontSize-1)+'px">'+esc(p.desc)+'</div>';h+='</div>';});}
    if(d.certs.length){h+=secTitleElegant('Certifications');d.certs.forEach(function(c){h+='<div style="margin-bottom:5px">• <strong>'+esc(c.name)+'</strong>';if(c.issuer)h+=' — '+esc(c.issuer);h+='</div>';});}
    if(d.langs.length){h+=secTitleElegant('Languages');h+='<div style="color:#555">'+d.langs.map(function(l){return esc(l);}).join(' · ')+'</div>';}
    h+='</div>';return h;
}

function renderCreative(d){
    var h='<div style="font-family:'+fontFamily+';font-size:'+fontSize+'px;line-height:'+lineSpacing+';color:'+textColor+'">';
    // Creative Header
    h+='<div style="background:'+headingColor+';padding:28px 35px;display:flex;align-items:center;gap:15px">';
    if(d.photo)h+='<img src="'+d.photo+'" style="width:65px;height:65px;border-radius:50%;object-fit:cover;border:3px solid '+accentColor+'">';
    else h+='<div style="width:60px;height:60px;border-radius:50%;background:'+accentColor+';display:flex;align-items:center;justify-content:center;color:#fff;font-size:22px;font-weight:700">'+esc((d.fname||'?')[0])+'</div>';
    h+='<div><div style="font-size:'+(fontSize+12)+'px;font-weight:700;color:#fff">'+esc(d.fullName||'Your Name')+'</div>';
    if(d.headline)h+='<div style="font-size:'+(fontSize)+'px;color:'+accentColor+';margin-top:2px">'+esc(d.headline)+'</div>';
    h+='</div></div>';
    // Two Column Body
    h+='<div style="display:flex">';
    // Left column
    h+='<div style="flex:1;padding:25px 30px">';
    var contact=[];
    if(d.email)contact.push('✉ '+esc(d.email));if(d.phone)contact.push('☎ '+esc(d.phone));if(d.address)contact.push('📍 '+esc(d.address));
    if(contact.length)h+='<div style="margin-bottom:18px;font-size:'+(fontSize-1)+'px;color:#666">'+contact.join('<br>')+'</div>';
    if(d.summary){h+=secTitleCreative('About Me');h+='<p style="margin:0 0 18px">'+esc(d.summary)+'</p>';}
    if(d.experience.length){h+=secTitleCreative('Experience');d.experience.forEach(function(e){h+='<div style="margin-bottom:12px"><div style="font-weight:600;color:'+headingColor+'">'+esc(e.title)+'</div><div style="color:'+accentColor+';font-size:'+(fontSize-1)+'px">'+esc(e.company)+(e.dur?' · '+esc(e.dur):'')+'</div>';if(e.desc)h+='<div style="color:#555;font-size:'+(fontSize-1)+'px;margin-top:3px">'+esc(e.desc)+'</div>';h+='</div>';});}
    if(d.education.length){h+=secTitleCreative('Education');d.education.forEach(function(e){h+='<div style="margin-bottom:8px"><div style="font-weight:600;color:'+headingColor+'">'+esc(e.deg)+'</div><div style="color:#666;font-size:'+(fontSize-1)+'px">'+esc(e.school)+(e.year?' · '+esc(e.year):'')+'</div></div>';});}
    h+='</div>';
    // Right column
    h+='<div style="width:180px;background:#f8f9fa;padding:25px 18px;border-left:3px solid '+accentColor+'">';
    if(d.skills.length){h+='<div style="font-weight:700;color:'+accentColor+';font-size:'+(fontSize)+'px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Skills</div>';d.skills.forEach(function(s){h+='<div style="background:'+accentColor+'18;color:'+headingColor+';padding:3px 8px;border-radius:4px;font-size:'+(fontSize-1)+'px;margin-bottom:4px">'+esc(s)+'</div>';});h+='<div style="margin-bottom:15px"></div>';}
    if(d.langs.length){h+='<div style="font-weight:700;color:'+accentColor+';font-size:'+(fontSize)+'px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Languages</div>';d.langs.forEach(function(l){h+='<div style="font-size:'+(fontSize-1)+'px;margin-bottom:4px;color:'+textColor+'">'+esc(l)+'</div>';});h+='<div style="margin-bottom:15px"></div>';}
    if(d.certs.length){h+='<div style="font-weight:700;color:'+accentColor+';font-size:'+(fontSize)+'px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Certs</div>';d.certs.forEach(function(c){h+='<div style="font-size:'+(fontSize-1)+'px;margin-bottom:5px"><strong>'+esc(c.name)+'</strong>';if(c.issuer)h+='<div style="color:#888;font-size:'+(fontSize-2)+'px">'+esc(c.issuer)+'</div>';h+='</div>';});}
    if(d.projects.length){h+='<div style="font-weight:700;color:'+accentColor+';font-size:'+(fontSize)+'px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Projects</div>';d.projects.forEach(function(p){h+='<div style="font-size:'+(fontSize-1)+'px;margin-bottom:5px"><strong>'+esc(p.name)+'</strong>';if(p.desc)h+='<div style="color:#888;font-size:'+(fontSize-2)+'px">'+esc(p.desc)+'</div>';h+='</div>';});}
    h+='</div></div></div>';return h;
}

// Helper Functions
function secTitle(t){return '<div style="font-size:'+(fontSize+2)+'px;font-weight:700;color:'+headingColor+';border-bottom:1px solid #ddd;padding-bottom:4px;margin:15px 0 10px;text-transform:uppercase;letter-spacing:0.5px">'+t+'</div>';}
function secTitlePro(t){return '<div style="font-size:'+(fontSize+1)+'px;font-weight:700;color:'+accentColor+';text-transform:uppercase;letter-spacing:1px;margin:16px 0 8px;border-bottom:1px solid #eee;padding-bottom:4px">'+t+'</div>';}
function secTitleModern(t){return '<div style="display:inline-block;background:'+accentColor+';color:#fff;padding:2px 10px;border-radius:3px;font-size:'+(fontSize-1)+'px;font-weight:700;letter-spacing:0.5px;text-transform:uppercase;margin:16px 0 10px">'+t+'</div>';}
function secTitleElegant(t){return '<div style="font-size:'+(fontSize+1)+'px;font-weight:700;color:'+headingColor+';text-transform:uppercase;letter-spacing:2px;margin:20px 0 10px;border-bottom:1px solid '+accentColor+';padding-bottom:5px">'+t+'</div>';}
function secTitleCreative(t){return '<div style="font-weight:700;color:'+accentColor+';font-size:'+(fontSize+1)+'px;margin:15px 0 8px;display:flex;align-items:center;gap:6px"><span style="width:4px;height:16px;background:'+accentColor+';border-radius:2px"></span>'+t+'</div>';}
function entryBlock(title,company,dur,loc,desc){
    var h='<div style="margin-bottom:12px"><div style="display:flex;justify-content:space-between;align-items:baseline"><div style="font-weight:600;color:'+headingColor+';font-size:'+(fontSize+1)+'px">'+esc(title||'')+'</div><div style="font-size:'+(fontSize-2)+'px;color:#999">'+esc(dur||'')+'</div></div>';
    h+='<div style="color:'+accentColor+';font-size:'+(fontSize-1)+'px;font-weight:500">'+esc(company||'')+(loc?' · '+esc(loc):'')+'</div>';
    if(desc)h+='<div style="color:#555;font-size:'+(fontSize-1)+'px;margin-top:4px">'+esc(desc)+'</div>';
    return h+'</div>';
}
function esc(s){if(!s)return '';var d=document.createElement('div');d.textContent=s;return d.innerHTML;}
function lighten(hex){
    var r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);
    r=Math.min(255,r+40);g=Math.min(255,g+40);b=Math.min(255,b+40);
    return '#'+[r,g,b].map(function(x){return x.toString(16).padStart(2,'0');}).join('');
}

// Render Preview
function rp(){
    var d=getData();
    var renderers={clean:renderClean,professional:renderProfessional,modern:renderModern,elegant:renderElegant,creative:renderCreative};
    var fn=renderers[curTpl]||renderClean;
    document.getElementById('cvPage').innerHTML=fn(d);
    updateProgress(d);
}

// Zoom
function zoom(delta){
    zoomVal=Math.max(0.4,Math.min(1.5,zoomVal+delta));
    document.getElementById('cvPage').style.transform='scale('+zoomVal+')';
    document.getElementById('zoomPct').textContent=Math.round(zoomVal*100)+'%';
}

// Download PDF
function downloadCV(){
    var el=document.getElementById('cvPage');
    var d=getData();
    var filename=(d.fullName||'CV').replace(/\s+/g,'_')+'_CV.pdf';
    var opt={
        margin:0,
        filename:filename,
        image:{type:'jpeg',quality:0.98},
        html2canvas:{scale:2,useCORS:true,letterRendering:true,scrollY:0},
        jsPDF:{unit:'pt',format:'a4',orientation:'portrait'}
    };
    // Show loading
    var btn=document.querySelector('.btn-download-cv');
    btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Generating...';
    btn.disabled=true;
    // IMPORTANT: Reset zoom/transform before PDF capture so layout is not broken
    var prevTransform=el.style.transform;
    el.style.transform='scale(1)';
    el.style.transformOrigin='top left';
    setTimeout(function(){
        html2pdf().set(opt).from(el).save().then(function(){
            // Restore zoom after download
            el.style.transform=prevTransform;
            el.style.transformOrigin='top center';
            btn.innerHTML='<i class="fas fa-download"></i> Download PDF';
            btn.disabled=false;
            if(typeof showToast==='function')showToast('PDF downloaded successfully!','success');
        }).catch(function(){
            el.style.transform=prevTransform;
            el.style.transformOrigin='top center';
            btn.innerHTML='<i class="fas fa-download"></i> Download PDF';
            btn.disabled=false;
            if(typeof showToast==='function')showToast('Download failed. Try again.','danger');
        });
    },150);
}

// Init
$(function(){
    document.getElementById('cvPage').style.transform='scale('+zoomVal+')';
    if(loadedCv){loadSavedCv();}else{addEdu(); addExp();}
    rp();
});
</script>
</body>
</html>