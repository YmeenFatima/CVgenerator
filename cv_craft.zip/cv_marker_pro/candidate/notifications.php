<?php
$pageTitle = 'Notifications';
require_once 'includes/header.php';

$cid = $_SESSION['candidate_id'];

// Mark all read
$db->prepare("UPDATE notifications SET is_read=1 WHERE candidate_id=?")->execute([$cid]);

$notifs = $db->prepare("SELECT * FROM notifications WHERE candidate_id=? ORDER BY created_at DESC");
$notifs->execute([$cid]);
$notifs = $notifs->fetchAll();

$icons = [
    'cv_downloaded'        => ['fas fa-download', 'var(--success)'],
    'template_update'      => ['fas fa-layer-group', 'var(--info)'],
    'profile_update'       => ['fas fa-user-circle', 'var(--accent)'],
    'welcome'              => ['fas fa-hand-wave', 'var(--warning)'],
    'general'              => ['fas fa-bell', 'var(--info)'],
    // legacy types (safe fallback)
    'application_received' => ['fas fa-bell', 'var(--info)'],
    'status_update'        => ['fas fa-bell', 'var(--info)'],
    'shortlisted'          => ['fas fa-bell', 'var(--info)'],
    'rejected'             => ['fas fa-bell', 'var(--info)'],
    'scored'               => ['fas fa-bell', 'var(--info)'],
    'hired'                => ['fas fa-bell', 'var(--info)'],
];
?>
<div class="topbar">
    <div class="page-title"><i class="fas fa-bell" style="color:var(--accent)"></i> Notifications</div>
</div>
<div class="content">
    <?php if (empty($notifs)): ?>
    <div class="card" style="text-align:center;padding:3rem">
        <i class="fas fa-bell-slash" style="font-size:3rem;opacity:0.2;margin-bottom:1rem;display:block"></i>
        <p style="color:var(--text-muted)">No notifications yet.</p>
    </div>
    <?php else: ?>
    <div class="card">
        <?php foreach ($notifs as $n):
            [$ic, $col] = $icons[$n['type']] ?? ['fas fa-info-circle', 'var(--info)'];
        ?>
        <div style="display:flex;gap:1rem;padding:1rem 0;border-bottom:1px solid var(--border);align-items:flex-start">
            <div style="width:38px;height:38px;border-radius:50%;background:rgba(255,255,255,0.05);display:flex;align-items:center;justify-content:center;flex-shrink:0;color:<?= $col ?>">
                <i class="<?= $ic ?>"></i>
            </div>
            <div style="flex:1">
                <div style="font-weight:600;font-size:0.9rem"><?= htmlspecialchars($n['title']) ?></div>
                <div style="color:var(--text-muted);font-size:0.85rem;margin-top:0.2rem"><?= htmlspecialchars($n['message']) ?></div>
                <div style="color:var(--text-muted);font-size:0.75rem;margin-top:0.4rem"><i class="fas fa-clock"></i> <?= formatDate($n['created_at'], 'd M Y, H:i') ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>
