<?php
$pageTitle = 'My CVs';
require_once 'includes/header.php';
$cid = $_SESSION['candidate_id'];
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $db->prepare('DELETE FROM cvs WHERE id=? AND candidate_id=?');
    $stmt->execute([$id, $cid]);
    logActivity('candidate', $cid, 'DELETE_CV', 'Deleted saved CV');
    setFlash('success', 'CV deleted successfully.');
    header('Location: cvs.php');
    exit;
}
$stmt = $db->prepare('SELECT * FROM cvs WHERE candidate_id=? ORDER BY updated_at DESC');
$stmt->execute([$cid]);
$cvs = $stmt->fetchAll();
?>
<div class="topbar">
    <div class="page-title"><i class="fas fa-file-lines" style="color:var(--accent)"></i> My Saved CVs</div>
    <div class="topbar-actions"><a href="cv_builder.php" class="topbar-btn primary"><i class="fas fa-plus"></i> New CV</a></div>
</div>
<div class="content">
    <div class="card">
        <div class="card-header"><div class="card-title">CV CRUD Manager</div><a href="cv_builder.php" class="btn btn-success btn-sm"><i class="fas fa-magic"></i> Open Builder</a></div>
        <?php if (empty($cvs)): ?>
            <div style="text-align:center;padding:3rem;color:var(--text-muted)">
                <i class="fas fa-file-circle-plus" style="font-size:3rem;opacity:.35;margin-bottom:1rem"></i>
                <h4 style="color:#e2e8f0">No saved CV yet</h4>
                <p>Create a CV, save it, edit it later, and download as PDF.</p>
                <a href="cv_builder.php" class="btn btn-success"><i class="fas fa-plus"></i> Create First CV</a>
            </div>
        <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Title</th><th>Template</th><th>Updated</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach($cvs as $cv): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($cv['title']) ?></strong><br><small style="color:var(--text-muted)">Created <?= formatDate($cv['created_at']) ?></small></td>
                        <td><span class="badge bg-info"><?= htmlspecialchars(ucfirst($cv['template'])) ?></span></td>
                        <td><?= formatDate($cv['updated_at'], 'd M Y h:i A') ?></td>
                        <td style="display:flex;gap:.4rem;flex-wrap:wrap">
                            <a class="btn btn-info btn-sm" href="cv_builder.php?id=<?= $cv['id'] ?>"><i class="fas fa-pen"></i> Edit</a>
                            <a class="btn btn-danger btn-sm" href="cvs.php?delete=<?= $cv['id'] ?>" onclick="return confirm('Delete this CV?')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>