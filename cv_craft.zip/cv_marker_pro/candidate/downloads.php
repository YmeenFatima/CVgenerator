<?php
$pageTitle = 'My Downloads';
require_once 'includes/header.php';
$cid = $_SESSION['candidate_id'];
$downloads = $db->prepare("SELECT dh.*, t.title, t.file_type, t.preview_image, c.name as cat_name, c.icon as cat_icon 
    FROM download_history dh 
    JOIN downloadable_templates t ON dh.template_id=t.id 
    JOIN template_categories c ON t.category_id=c.id 
    WHERE dh.user_id=? ORDER BY dh.downloaded_at DESC");
$downloads->execute([$cid]);
$downloads = $downloads->fetchAll();
?>
<div class="topbar">
    <div class="page-title"><i class="fas fa-download" style="color:var(--accent)"></i> My Downloads</div>
</div>
<div class="content" style="padding:1.5rem">
    <div style="margin-bottom:1.5rem">
        <h2 style="font-family:'Sora',sans-serif;font-size:1.3rem;font-weight:700">Download History</h2>
        <p style="color:#64748b;font-size:0.85rem">You have downloaded <?= count($downloads) ?> template(s).</p>
    </div>
    <?php if(empty($downloads)): ?>
    <div style="text-align:center;padding:3rem;color:#475569">
        <i class="fas fa-download" style="font-size:3rem;display:block;margin-bottom:1rem;opacity:0.3"></i>
        <p>No downloads yet. <a href="<?= SITE_URL ?>/templates_browse.php" style="color:var(--accent)">Browse templates</a></p>
    </div>
    <?php else: ?>
    <div class="card" style="background:#1e293b;border:1px solid rgba(255,255,255,0.07);border-radius:14px;overflow:hidden">
    <div class="table-responsive">
    <table class="table table-dark-custom mb-0">
        <thead><tr><th>Template</th><th>Category</th><th>Type</th><th>Downloaded</th><th>Action</th></tr></thead>
        <tbody>
        <?php foreach($downloads as $dl): ?>
        <tr>
            <td><strong><?= htmlspecialchars($dl['title']) ?></strong></td>
            <td><i class="fas <?= $dl['cat_icon'] ?> me-1" style="color:#6366f1"></i><?= htmlspecialchars($dl['cat_name']) ?></td>
            <td><span class="badge bg-secondary"><?= strtoupper($dl['file_type']) ?></span></td>
            <td><?= formatDate($dl['downloaded_at'], 'd M Y H:i') ?></td>
            <td><a href="<?= SITE_URL ?>/download.php?id=<?= $dl['template_id'] ?>" class="btn btn-sm" style="background:#6366f1;color:#fff;font-size:0.78rem"><i class="fas fa-download me-1"></i>Re-download</a></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    </div>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>
