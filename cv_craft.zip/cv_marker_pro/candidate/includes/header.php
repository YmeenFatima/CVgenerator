<?php
require_once dirname(dirname(__DIR__)) . '/includes/config.php';
requireCandidate();
$db = getDB();
$candStmt = $db->prepare("SELECT * FROM candidates WHERE id=?");
$candStmt->execute([$_SESSION['candidate_id']]);
$currentCandidate = $candStmt->fetch();
$currentCandidateName = getCandidateName($currentCandidate ?: []);
$unreadNotif = $db->prepare("SELECT COUNT(*) FROM notifications WHERE candidate_id=? AND is_read=0");
$unreadNotif->execute([$_SESSION['candidate_id']]);
$unreadNotif = $unreadNotif->fetchColumn();
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?? 'Dashboard' ?> — CV Craft</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Sora:wght@600;700;800&display=swap" rel="stylesheet">
<link href="<?= SITE_URL ?>/includes/common.css" rel="stylesheet">
<style>
body { font-family:'Inter',sans-serif; background:#0f172a; color:#e2e8f0; margin:0; }
.sidebar { background:#1e293b; }
.sidebar-logo .logo-box { background:linear-gradient(135deg,#10b981,#059669); }
.sidebar-nav li a.active { background:rgba(16,185,129,0.15); color:#10b981; }
</style>
</head>
<body class="dark-mode">
<div id="toaster-container"></div>

<div class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <div class="logo-box"><i class="fas fa-user-tie"></i></div>
    <div><h2>CV Craft</h2><small>Candidate Portal</small></div>
  </div>

  <div class="sidebar-section">Menu</div>
  <ul class="sidebar-nav">
    <li><a href="<?= CANDIDATE_URL ?>/dashboard.php" class="<?= $currentPage==='dashboard.php'?'active':'' ?>"><i class="fas fa-home"></i> Dashboard</a></li>
    <li><a href="<?= CANDIDATE_URL ?>/cv_builder.php" class="<?= $currentPage==='cv_builder.php'?'active':'' ?>"><i class="fas fa-magic"></i> CV Builder</a></li>
    <li><a href="<?= CANDIDATE_URL ?>/cvs.php" class="<?= $currentPage==='cvs.php'?'active':'' ?>"><i class="fas fa-file-lines"></i> My CVs</a></li>
    <li><a href="<?= CANDIDATE_URL ?>/cover_letters.php" class="<?= $currentPage==='cover_letters.php'?'active':'' ?>"><i class="fas fa-envelope-open-text"></i> Cover Letters</a></li>
    <li><a href="<?= SITE_URL ?>/templates_browse.php"><i class="fas fa-layer-group"></i> Template Library</a></li>
    <li><a href="<?= CANDIDATE_URL ?>/downloads.php" class="<?= $currentPage==='downloads.php'?'active':'' ?>"><i class="fas fa-download"></i> My Downloads</a></li>
    <li><a href="<?= CANDIDATE_URL ?>/favorites.php" class="<?= $currentPage==='favorites.php'?'active':'' ?>"><i class="fas fa-heart"></i> Favorites</a></li>
    <li><a href="<?= CANDIDATE_URL ?>/notifications.php" class="<?= $currentPage==='notifications.php'?'active':'' ?>">
      <i class="fas fa-bell"></i> Notifications
      <?php if($unreadNotif>0): ?><span class="nav-badge"><?= $unreadNotif ?></span><?php endif; ?>
    </a></li>
    <li><a href="<?= CANDIDATE_URL ?>/profile.php" class="<?= $currentPage==='profile.php'?'active':'' ?>"><i class="fas fa-user-circle"></i> My Profile</a></li>

  </ul>

  <div class="sidebar-section">Account</div>
  <ul class="sidebar-nav">
    <li><a href="<?= CANDIDATE_URL ?>/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
  </ul>

  <div class="sidebar-user">
    <div class="avatar-circle" style="background:linear-gradient(135deg,#10b981,#059669)">
      <?= strtoupper(substr($currentCandidateName ?: 'C', 0, 1)) ?>
    </div>
    <div style="flex:1;min-width:0">
      <div style="font-size:0.85rem;font-weight:600;color:#f1f5f9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($currentCandidateName) ?></div>
      <div style="font-size:0.72rem;color:#64748b">Candidate</div>
    </div>
  </div>
</div>

<div class="main-wrap">
<div class="topbar">
  <div class="d-flex align-items-center gap-3">
    <button id="sidebarToggle" class="d-md-none btn btn-sm" style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:#94a3b8"><i class="fas fa-bars"></i></button>
    <span class="topbar-title"><?= $pageTitle ?? 'Dashboard' ?></span>
  </div>
  <div class="d-flex align-items-center gap-3">
    <select class="theme-select" id="themeSwitcher" title="Theme">
      <option value="blue">Blue</option>
      <option value="dark">Dark</option>
      <option value="purple">Purple</option>
      <option value="green">Green</option>
    </select>
    <button class="dark-toggle active" id="darkToggle" data-bs-toggle="tooltip" title="Toggle dark mode"></button>
    <a href="<?= SITE_URL ?>/login.php" class="btn btn-sm" style="background:rgba(233,69,96,0.1);border:1px solid rgba(233,69,96,0.2);color:#f87171;font-size:0.8rem" data-bs-toggle="tooltip" title="Admin Panel"><i class="fas fa-user-shield"></i></a>
    <a href="<?= CANDIDATE_URL ?>/logout.php" class="btn btn-sm" style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#f87171;font-size:0.8rem"><i class="fas fa-sign-out-alt"></i></a>
  </div>
</div>
<?php
$flash = getFlash();
if ($flash): ?>
<script>document.addEventListener('DOMContentLoaded',()=>showToast('<?= addslashes($flash['message']) ?>','<?= $flash['type'] ?>'));</script>
<?php endif; ?>
