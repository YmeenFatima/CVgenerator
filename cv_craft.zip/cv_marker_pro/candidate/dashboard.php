<?php
$pageTitle = 'Dashboard';
require_once 'includes/header.php';

$cid = $_SESSION['candidate_id'];

try { $totalCvs = $db->prepare("SELECT COUNT(*) FROM cvs WHERE candidate_id = ?"); $totalCvs->execute([$cid]); $totalCvs = $totalCvs->fetchColumn(); } catch(Exception $e) { $totalCvs = 0; }
try { $totalDownloads = $db->prepare("SELECT COUNT(*) FROM download_history WHERE user_id = ?"); $totalDownloads->execute([$cid]); $totalDownloads = $totalDownloads->fetchColumn(); } catch(Exception $e) { $totalDownloads = 0; }
try { $totalFavs = $db->prepare("SELECT COUNT(*) FROM favorites WHERE user_id = ?"); $totalFavs->execute([$cid]); $totalFavs = $totalFavs->fetchColumn(); } catch(Exception $e) { $totalFavs = 0; }
try { $totalTemplates = $db->query("SELECT COUNT(*) FROM downloadable_templates WHERE is_active=1")->fetchColumn(); } catch(Exception $e) { $totalTemplates = 0; }

try {
    $recentCvs = $db->prepare("SELECT * FROM cvs WHERE candidate_id = ? ORDER BY updated_at DESC LIMIT 5");
    $recentCvs->execute([$cid]);
    $recentCvs = $recentCvs->fetchAll();
} catch(Exception $e) { $recentCvs = []; }
?>
<div class="topbar">
    <div class="page-title"><i class="fas fa-home" style="color:var(--accent)"></i> Dashboard</div>
    <div class="topbar-actions">
        <a href="cv_builder.php" class="topbar-btn primary"><i class="fas fa-magic"></i> Build New CV</a>
    </div>
</div>
<div class="content">
    <div style="margin-bottom:1.5rem">
        <h2 style="font-family:'Sora',sans-serif;font-size:1.4rem;font-weight:700;">Welcome back, <?= htmlspecialchars(trim(($currentCandidate['first_name'] ?? '') . ' ' . ($currentCandidate['last_name'] ?? ''))) ?>! 👋</h2>
        <p style="color:var(--text-muted);margin-top:0.3rem">Here's your CV overview.</p>
    </div>

    <div class="stats-grid">
        <div class="stat-card" style="border-left:3px solid var(--accent)">
            <div class="icon" style="color:var(--accent)"><i class="fas fa-file-lines"></i></div>
            <div class="num"><?= $totalCvs ?></div>
            <div class="label">My CVs</div>
        </div>
        <div class="stat-card" style="border-left:3px solid var(--success)">
            <div class="icon" style="color:var(--success)"><i class="fas fa-download"></i></div>
            <div class="num"><?= $totalDownloads ?></div>
            <div class="label">Downloads</div>
        </div>
        <div class="stat-card" style="border-left:3px solid #ef4444">
            <div class="icon" style="color:#ef4444"><i class="fas fa-heart"></i></div>
            <div class="num"><?= $totalFavs ?></div>
            <div class="label">Saved Templates</div>
        </div>
        <div class="stat-card" style="border-left:3px solid #8b5cf6">
            <div class="icon" style="color:#8b5cf6"><i class="fas fa-layer-group"></i></div>
            <div class="num"><?= $totalTemplates ?></div>
            <div class="label">Available Templates</div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title"><i class="fas fa-file-lines" style="color:var(--accent)"></i> Recent CVs</div>
            <a href="cvs.php" class="btn btn-secondary btn-sm">View All</a>
        </div>
        <?php if (empty($recentCvs)): ?>
        <div style="text-align:center;padding:2.5rem;color:var(--text-muted)">
            <i class="fas fa-file-lines" style="font-size:2.5rem;margin-bottom:1rem;display:block;opacity:0.3"></i>
            <p>No CVs yet. <a href="cv_builder.php" style="color:var(--accent)">Build your first CV</a></p>
        </div>
        <?php else: ?>
        <div class="table-wrap">
        <table>
            <thead><tr><th>CV Title</th><th>Template</th><th>Last Updated</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($recentCvs as $cv): ?>
            <tr>
                <td><strong><?= htmlspecialchars($cv['title'] ?? 'Untitled CV') ?></strong></td>
                <td><?= htmlspecialchars(ucfirst($cv['template'] ?? '—')) ?></td>
                <td><?= formatDate($cv['updated_at']) ?></td>
                <td><a href="cv_builder.php?id=<?= $cv['id'] ?>" class="btn btn-info btn-sm"><i class="fas fa-edit"></i></a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
