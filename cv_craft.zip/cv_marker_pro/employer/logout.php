<?php
require_once dirname(__DIR__) . '/includes/config.php';
unset($_SESSION['employer_id'], $_SESSION['employer_name']);
setFlash('success', 'Employer logged out successfully.');
header('Location: login.php');
exit;
?>