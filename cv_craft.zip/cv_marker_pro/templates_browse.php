<?php
require_once 'includes/config.php';
$db = getDB();

// Get categories
$cats = $db->query("SELECT * FROM template_categories WHERE is_active=1 ORDER BY sort_order")->fetchAll();

// Filters
$catFilter = isset($_GET['category']) ? sanitize($_GET['category']) : '';
$search = isset($_GET['q']) ? sanitize($_GET['q']) : '';
$sort = isset($_GET['sort']) ? sanitize($_GET['sort']) : 'newest';

// Pagination
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 12;
$offset = ($page - 1) * $perPage;

// Build query
$where = "WHERE t.is_active=1";
$params = [];
if ($catFilter) {
    $where .= " AND c.slug=?";
    $params[] = $catFilter;
}
if ($search) {
    $where .= " AND (t.title LIKE ? OR t.description LIKE ? OR t.tags LIKE ?)";
    $s = "%$search%";
    $params[] = $s; $params[] = $s; $params[] = $s;
}

$orderBy = match($sort) {
    'popular' => 'ORDER BY t.download_count DESC',
    'oldest' => 'ORDER BY t.created_at ASC',
    default => 'ORDER BY t.created_at DESC'
};

// Count total
$countStmt = $db->prepare("SELECT COUNT(*) FROM downloadable_templates t JOIN template_categories c ON t.category_id=c.id $where");
$countStmt->execute($params);
$totalItems = $countStmt->fetchColumn();
$totalPages = ceil($totalItems / $perPage);

// Fetch templates
$stmt = $db->prepare("SELECT t.*, c.name as category_name, c.slug as category_slug, c.icon as category_icon 
    FROM downloadable_templates t 
    JOIN template_categories c ON t.category_id=c.id 
    $where $orderBy LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$templates = $stmt->fetchAll();

// Check favorites if logged in
$userFavorites = [];
if (isset($_SESSION['candidate_id'])) {
    $favStmt = $db->prepare("SELECT template_id FROM favorites WHERE user_id=?");
    $favStmt->execute([$_SESSION['candidate_id']]);
    $userFavorites = $favStmt->fetchAll(PDO::FETCH_COLUMN);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Templates — <?= SITE_NAME ?></title>
<?php include 'includes/assets.php'; ?>
<link href="includes/common.css" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#0a0f1e;color:#e2e8f0;}

/* Navbar */
.nav-top{position:sticky;top:0;z-index:100;background:rgba(10,15,30,0.95);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);padding:0.8rem 0;}
.nav-inner{max-width:1280px;margin:0 auto;padding:0 2rem;display:flex;align-items:center;justify-content:space-between;}
.brand{display:flex;align-items:center;gap:0.6rem;text-decoration:none;}
.brand-box{width:34px;height:34px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:8px;display:flex;align-items:center;justify-content:center;}
.brand-txt{font-family:'Sora',sans-serif;font-size:1.05rem;font-weight:800;color:#f1f5f9;}
.brand-txt span{color:#6366f1;}
.nav-links{display:flex;align-items:center;gap:1.5rem;}
.nav-links a{color:#94a3b8;font-size:0.85rem;font-weight:500;text-decoration:none;transition:color 0.2s;}
.nav-links a:hover,.nav-links a.active{color:#f1f5f9;}
.nav-btns{display:flex;gap:0.6rem;}
.btn-nav-outline{border:1px solid rgba(255,255,255,0.15);color:#e2e8f0;padding:0.4rem 1rem;border-radius:8px;font-size:0.82rem;font-weight:600;text-decoration:none;transition:all 0.2s;}
.btn-nav-outline:hover{background:rgba(255,255,255,0.07);color:#fff;}
.btn-nav-primary{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;padding:0.4rem 1.1rem;border-radius:8px;font-size:0.82rem;font-weight:700;text-decoration:none;transition:all 0.2s;}
.btn-nav-primary:hover{box-shadow:0 4px 16px rgba(99,102,241,0.4);color:#fff;}

/* Page Header */
.page-header{padding:3rem 0;text-align:center;background:radial-gradient(ellipse at 50% 0%,rgba(99,102,241,0.1),transparent 60%);}
.page-header h1{font-family:'Sora',sans-serif;font-size:2.2rem;font-weight:800;color:#f1f5f9;margin-bottom:0.5rem;}
.page-header p{color:#64748b;font-size:0.95rem;}

/* Filters */
.filter-bar{max-width:1280px;margin:0 auto;padding:0 2rem 1.5rem;display:flex;flex-wrap:wrap;gap:1rem;align-items:center;justify-content:space-between;}
.cat-pills{display:flex;gap:0.4rem;flex-wrap:wrap;}
.cat-pill{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);color:#94a3b8;padding:0.4rem 1rem;border-radius:20px;font-size:0.8rem;font-weight:600;text-decoration:none;transition:all 0.2s;}
.cat-pill:hover,.cat-pill.active{background:#6366f1;border-color:#6366f1;color:#fff;}
.search-sort{display:flex;gap:0.8rem;align-items:center;}
.search-box{position:relative;}
.search-box input{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#e2e8f0;padding:0.5rem 1rem 0.5rem 2.3rem;border-radius:10px;font-size:0.85rem;width:240px;outline:none;transition:border-color 0.2s;}
.search-box input:focus{border-color:#6366f1;}
.search-box i{position:absolute;left:0.8rem;top:50%;transform:translateY(-50%);color:#475569;font-size:0.85rem;}
.sort-select{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#e2e8f0;padding:0.5rem 0.8rem;border-radius:10px;font-size:0.82rem;outline:none;}
.sort-select option{background:#1e293b;}

/* Template Grid */
.tpl-grid{max-width:1280px;margin:0 auto;padding:0 2rem 3rem;display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.5rem;}
.tpl-card{background:#1e293b;border:1px solid rgba(255,255,255,0.07);border-radius:16px;overflow:hidden;transition:all 0.3s;}
.tpl-card:hover{transform:translateY(-5px);border-color:rgba(99,102,241,0.3);box-shadow:0 16px 40px rgba(0,0,0,0.3);}
.tpl-img{aspect-ratio:3/4;background:#2d3748;position:relative;overflow:hidden;}
.tpl-img img{width:100%;height:100%;object-fit:cover;}
.tpl-img .placeholder-cv{width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#1e293b,#334155);}
.tpl-img .placeholder-cv i{font-size:3rem;color:#475569;}
.mock-preview{width:72%;height:82%;background:#f8fafc;border-radius:8px;padding:18px;box-shadow:0 18px 30px rgba(0,0,0,0.25);display:flex;flex-direction:column;gap:8px;}
.mock-preview .bar{height:8px;border-radius:8px;background:#cbd5e1;}
.mock-preview .bar.title{height:16px;width:70%;background:#6366f1;}
.mock-preview .bar.mid{width:82%;}
.mock-preview .bar.short{width:54%;}
.mock-preview .section{height:2px;background:#6366f1;margin:6px 0 2px;}
.tpl-overlay{position:absolute;inset:0;background:rgba(99,102,241,0.9);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0.6rem;opacity:0;transition:opacity 0.3s;}
.tpl-card:hover .tpl-overlay{opacity:1;}
.tpl-overlay a,.tpl-overlay button{width:150px;padding:0.5rem;border-radius:8px;font-size:0.82rem;font-weight:700;text-align:center;text-decoration:none;border:none;cursor:pointer;transition:all 0.2s;}
.tpl-overlay .btn-view{background:#fff;color:#4f46e5;}
.tpl-overlay .btn-dl{background:rgba(255,255,255,0.15);border:1px solid rgba(255,255,255,0.4);color:#fff;}
.tpl-badges{position:absolute;top:0.6rem;left:0.6rem;display:flex;gap:0.3rem;z-index:3;}
.tpl-badge{padding:0.18rem 0.5rem;border-radius:4px;font-size:0.65rem;font-weight:700;}
.badge-featured{background:#f59e0b;color:#000;}
.badge-new{background:#6366f1;color:#fff;}
.badge-free{background:#10b981;color:#fff;}
.tpl-info{padding:1rem 1.2rem;}
.tpl-cat{font-size:0.72rem;font-weight:600;color:#6366f1;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:0.3rem;}
.tpl-title{font-family:'Sora',sans-serif;font-size:0.92rem;font-weight:700;color:#f1f5f9;margin-bottom:0.3rem;}
.tpl-desc{font-size:0.78rem;color:#64748b;line-height:1.5;margin-bottom:0.8rem;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
.tpl-meta{display:flex;align-items:center;justify-content:space-between;}
.tpl-downloads{font-size:0.75rem;color:#64748b;display:flex;align-items:center;gap:0.3rem;}
.tpl-actions-row{display:flex;gap:0.4rem;}
.btn-fav{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#f87171;width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all 0.2s;font-size:0.8rem;}
.btn-fav:hover,.btn-fav.active{background:rgba(239,68,68,0.25);color:#ef4444;}
.btn-fav.active i{font-weight:900;}
.btn-dl-sm{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;padding:0.4rem 0.8rem;border-radius:8px;font-size:0.78rem;font-weight:700;text-decoration:none;display:flex;align-items:center;gap:0.3rem;transition:all 0.2s;}
.btn-dl-sm:hover{box-shadow:0 4px 12px rgba(99,102,241,0.4);color:#fff;}

/* Pagination */
.pagination-wrap{max-width:1280px;margin:0 auto;padding:0 2rem 3rem;display:flex;justify-content:center;gap:0.4rem;}
.pg-btn{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);color:#94a3b8;padding:0.5rem 0.9rem;border-radius:8px;font-size:0.82rem;font-weight:600;text-decoration:none;transition:all 0.2s;}
.pg-btn:hover,.pg-btn.active{background:#6366f1;border-color:#6366f1;color:#fff;}

/* Empty State */
.empty-state{text-align:center;padding:4rem 2rem;color:#475569;}
.empty-state i{font-size:3rem;margin-bottom:1rem;display:block;}

/* Footer */
.site-footer{background:#0f172a;border-top:1px solid rgba(255,255,255,0.06);padding:2rem 0;text-align:center;color:#475569;font-size:0.82rem;}

@media(max-width:768px){
    .filter-bar{flex-direction:column;align-items:stretch;}
    .search-sort{flex-direction:column;}
    .search-box input{width:100%;}
    .tpl-grid{grid-template-columns:repeat(auto-fill,minmax(240px,1fr));}
}
</style>
</head>
<body>
<div id="toaster-container"></div>

<!-- Navbar -->
<nav class="nav-top">
<div class="nav-inner">
    <a href="<?= SITE_URL ?>" class="brand">
        <div class="brand-box"><i class="fas fa-file-alt" style="color:#fff;font-size:0.85rem"></i></div>
        <span class="brand-txt">CV <span>Craft</span></span>
    </a>
    <div class="nav-links d-none d-md-flex">
        <a href="<?= SITE_URL ?>">Home</a>
        <a href="<?= SITE_URL ?>/templates_browse.php" class="active">Templates</a>
        <a href="<?= SITE_URL ?>/about.php">About</a>
        <a href="<?= SITE_URL ?>/contact.php">Contact</a>
    </div>
    <div class="nav-btns">
        <?php if(isset($_SESSION['candidate_id'])): ?>
        <a href="<?= CANDIDATE_URL ?>/dashboard.php" class="btn-nav-outline"><i class="fas fa-user me-1"></i>Dashboard</a>
        <a href="<?= CANDIDATE_URL ?>/logout.php" class="btn-nav-primary"><i class="fas fa-sign-out-alt me-1"></i>Logout</a>
        <?php else: ?>
        <a href="<?= SITE_URL ?>/login.php" class="btn-nav-outline">Log In</a>
        <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-nav-primary">Sign Up</a>
        <?php endif; ?>
    </div>
</div>
</nav>

<!-- Page Header -->
<div class="page-header">
    <h1><i class="fas fa-layer-group me-2" style="color:#6366f1"></i>Template Library</h1>
    <p>Browse <?= $totalItems ?> professional templates. Download for free!</p>
</div>

<!-- Filter Bar -->
<div class="filter-bar">
    <div class="cat-pills">
        <a href="templates_browse.php" class="cat-pill <?= !$catFilter ? 'active' : '' ?>">All</a>
        <?php foreach($cats as $cat): ?>
        <a href="templates_browse.php?category=<?= $cat['slug'] ?>" class="cat-pill <?= $catFilter===$cat['slug'] ? 'active' : '' ?>">
            <i class="fas <?= $cat['icon'] ?> me-1"></i><?= htmlspecialchars($cat['name']) ?>
        </a>
        <?php endforeach; ?>
    </div>
    <div class="search-sort">
        <form class="search-box" method="GET">
            <?php if($catFilter): ?><input type="hidden" name="category" value="<?= htmlspecialchars($catFilter) ?>"><?php endif; ?>
            <i class="fas fa-search"></i>
            <input type="text" name="q" placeholder="Search templates..." value="<?= htmlspecialchars($search) ?>">
        </form>
        <select class="sort-select" onchange="location.href=this.value">
            <option value="templates_browse.php?sort=newest<?= $catFilter?"&category=$catFilter":'' ?>" <?= $sort==='newest'?'selected':'' ?>>Newest</option>
            <option value="templates_browse.php?sort=popular<?= $catFilter?"&category=$catFilter":'' ?>" <?= $sort==='popular'?'selected':'' ?>>Most Popular</option>
            <option value="templates_browse.php?sort=oldest<?= $catFilter?"&category=$catFilter":'' ?>" <?= $sort==='oldest'?'selected':'' ?>>Oldest</option>
        </select>
    </div>
</div>

<!-- Template Grid -->
<?php if(empty($templates)): ?>
<div class="empty-state">
    <i class="fas fa-search"></i>
    <h3 style="color:#94a3b8;margin-bottom:0.5rem">No templates found</h3>
    <p>Try adjusting your filters or search terms.</p>
</div>
<?php else: ?>
<div class="tpl-grid">
    <?php foreach($templates as $tpl): ?>
    <div class="tpl-card">
        <div class="tpl-img">
            <?php if($tpl['preview_image'] && file_exists(__DIR__.'/uploads/'.$tpl['preview_image'])): ?>
            <img src="<?= SITE_URL ?>/uploads/<?= $tpl['preview_image'] ?>" alt="<?= htmlspecialchars($tpl['title']) ?>">
            <?php else: ?>
            <div class="placeholder-cv">
                <div class="mock-preview">
                    <div class="bar title"></div><div class="bar mid"></div><div class="bar short"></div>
                    <div class="section"></div><div class="bar"></div><div class="bar mid"></div>
                    <div class="section"></div><div class="bar short"></div><div class="bar"></div>
                </div>
            </div>
            <?php endif; ?>
            <div class="tpl-badges">
                <?php if($tpl['is_featured']): ?><span class="tpl-badge badge-featured"><i class="fas fa-star me-1"></i>Featured</span><?php endif; ?>
                <?php if(strtotime($tpl['created_at']) > strtotime('-7 days')): ?><span class="tpl-badge badge-new">New</span><?php endif; ?>
                <span class="tpl-badge badge-free">Free</span>
            </div>
            <div class="tpl-overlay">
                <a href="template_detail.php?id=<?= $tpl['id'] ?>" class="btn-view"><i class="fas fa-eye me-1"></i>View Details</a>
                <?php if(isset($_SESSION['candidate_id'])): ?>
                <a href="download.php?id=<?= $tpl['id'] ?>" class="btn-dl"><i class="fas fa-download me-1"></i>Download</a>
                <?php else: ?>
                <a href="login.php" class="btn-dl"><i class="fas fa-lock me-1"></i>Login to Download</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="tpl-info">
            <div class="tpl-cat"><i class="fas <?= $tpl['category_icon'] ?> me-1"></i><?= htmlspecialchars($tpl['category_name']) ?></div>
            <div class="tpl-title"><?= htmlspecialchars($tpl['title']) ?></div>
            <div class="tpl-desc"><?= htmlspecialchars($tpl['description']) ?></div>
            <div class="tpl-meta">
                <span class="tpl-downloads"><i class="fas fa-download"></i> <?= number_format($tpl['download_count']) ?></span>
                <div class="tpl-actions-row">
                    <?php if(isset($_SESSION['candidate_id'])): ?>
                    <button class="btn-fav <?= in_array($tpl['id'], $userFavorites) ? 'active' : '' ?>" onclick="toggleFav(<?= $tpl['id'] ?>,this)" title="Add to favorites">
                        <i class="<?= in_array($tpl['id'], $userFavorites) ? 'fas' : 'far' ?> fa-heart"></i>
                    </button>
                    <?php endif; ?>
                    <a href="template_detail.php?id=<?= $tpl['id'] ?>" class="btn-dl-sm"><i class="fas fa-eye"></i></a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Pagination -->
<?php if($totalPages > 1): ?>
<div class="pagination-wrap">
    <?php if($page > 1): ?>
    <a href="?page=<?= $page-1 ?>&category=<?= $catFilter ?>&sort=<?= $sort ?>&q=<?= urlencode($search) ?>" class="pg-btn"><i class="fas fa-chevron-left"></i></a>
    <?php endif; ?>
    <?php for($i=1; $i<=$totalPages; $i++): ?>
    <a href="?page=<?= $i ?>&category=<?= $catFilter ?>&sort=<?= $sort ?>&q=<?= urlencode($search) ?>" class="pg-btn <?= $i===$page?'active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if($page < $totalPages): ?>
    <a href="?page=<?= $page+1 ?>&category=<?= $catFilter ?>&sort=<?= $sort ?>&q=<?= urlencode($search) ?>" class="pg-btn"><i class="fas fa-chevron-right"></i></a>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php endif; ?>

<!-- Footer -->
<footer class="site-footer">
    <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="includes/common.js"></script>
<script>
function toggleFav(tid, btn) {
    fetch('ajax/toggle_favorite.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'template_id=' + tid
    }).then(r => r.json()).then(d => {
        if (d.success) {
            btn.classList.toggle('active');
            btn.querySelector('i').className = d.is_fav ? 'fas fa-heart' : 'far fa-heart';
            showToast(d.message, 'success');
        } else {
            showToast(d.message || 'Error', 'danger');
        }
    });
}
</script>
<?php include 'includes/toaster.php'; ?>
</body>
</html>
