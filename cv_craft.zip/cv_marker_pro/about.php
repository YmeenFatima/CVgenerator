<?php require_once 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>About — <?= SITE_NAME ?></title>
<?php include 'includes/assets.php'; ?>
<link href="includes/common.css" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#0a0f1e;color:#e2e8f0;}
.nav-top{position:sticky;top:0;z-index:100;background:rgba(10,15,30,0.95);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);padding:0.8rem 0;}
.nav-inner{max-width:1280px;margin:0 auto;padding:0 2rem;display:flex;align-items:center;justify-content:space-between;}
.brand{display:flex;align-items:center;gap:0.6rem;text-decoration:none;}
.brand-box{width:34px;height:34px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:8px;display:flex;align-items:center;justify-content:center;}
.brand-txt{font-family:'Sora',sans-serif;font-size:1.05rem;font-weight:800;color:#f1f5f9;}
.brand-txt span{color:#6366f1;}
.nav-links{display:flex;align-items:center;gap:1.5rem;}
.nav-links a{color:#94a3b8;font-size:0.85rem;font-weight:500;text-decoration:none;}
.nav-links a:hover,.nav-links a.active{color:#f1f5f9;}
.content{max-width:800px;margin:4rem auto;padding:0 2rem;}
.content h1{font-family:'Sora',sans-serif;font-size:2rem;font-weight:800;margin-bottom:1.5rem;color:#f1f5f9;}
.content p{color:#94a3b8;font-size:0.95rem;line-height:1.9;margin-bottom:1.2rem;}
.content h3{font-family:'Sora',sans-serif;font-size:1.2rem;font-weight:700;margin:2rem 0 1rem;color:#f1f5f9;}
.feature-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:1.2rem;margin:2rem 0;}
.feat{background:#1e293b;border:1px solid rgba(255,255,255,0.07);border-radius:14px;padding:1.5rem;text-align:center;}
.feat i{font-size:1.8rem;color:#6366f1;margin-bottom:0.8rem;display:block;}
.feat h5{font-family:'Sora',sans-serif;font-size:0.9rem;font-weight:700;color:#f1f5f9;margin-bottom:0.3rem;}
.feat p{font-size:0.82rem;color:#64748b;margin:0;}
.site-footer{background:#0f172a;border-top:1px solid rgba(255,255,255,0.06);padding:2rem 0;text-align:center;color:#475569;font-size:0.82rem;margin-top:3rem;}
</style>
</head>
<body>
<nav class="nav-top"><div class="nav-inner">
    <a href="<?= SITE_URL ?>" class="brand"><div class="brand-box"><i class="fas fa-file-alt" style="color:#fff;font-size:0.85rem"></i></div><span class="brand-txt">CV <span>Craft</span></span></a>
    <div class="nav-links d-none d-md-flex"><a href="<?= SITE_URL ?>">Home</a><a href="<?= SITE_URL ?>/templates_browse.php">Templates</a><a href="<?= SITE_URL ?>/about.php" class="active">About</a><a href="<?= SITE_URL ?>/contact.php">Contact</a></div>
</div></nav>
<div class="content">
    <h1>About <?= SITE_NAME ?></h1>
    <p><?= SITE_NAME ?> is a comprehensive platform designed to help professionals create stunning CVs, resumes, and career documents. Our mission is to empower job seekers with the tools and templates they need to stand out in today's competitive job market.</p>
    <p>Whether you're a fresh graduate or a seasoned professional, our platform offers everything from AI-powered CV scoring to a vast library of downloadable templates across multiple categories.</p>
    <h3>What We Offer</h3>
    <div class="feature-grid">
        <div class="feat"><i class="fas fa-magic"></i><h5>CV Builder</h5><p>Create professional CVs with our intuitive drag-and-drop builder</p></div>
        <div class="feat"><i class="fas fa-download"></i><h5>Template Library</h5><p>Browse and download 100+ professional templates</p></div>
        <div class="feat"><i class="fas fa-robot"></i><h5>AI Scoring</h5><p>Get your CV scored by our AI engine for optimization</p></div>
        <div class="feat"><i class="fas fa-briefcase"></i><h5>Job Applications</h5><p>Apply to jobs directly through our platform</p></div>
    </div>
    <h3>Our Mission</h3>
    <p>We believe everyone deserves access to professional career tools. That's why our platform is free to use and our templates are available for download at no cost. We're committed to helping you land your dream job.</p>
</div>
<footer class="site-footer"><p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</p></footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
