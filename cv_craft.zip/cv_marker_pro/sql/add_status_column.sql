-- Migration to add status column to candidates table
-- Run this SQL if you have an existing database

ALTER TABLE candidates 
ADD COLUMN status ENUM('student','employed','unemployed','freelancer') NULL 
AFTER city;
